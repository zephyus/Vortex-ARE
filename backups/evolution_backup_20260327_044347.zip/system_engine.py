import psutil
import time
import os
import json
import sys
import zipfile
import csv
from datetime import datetime
from typing import List, Dict, Any
import subprocess
import pyautogui
import random
import re

class SystemEngine:
    def __init__(self, config_path="config.json", log_path="app.log"):
        self.config_path = config_path
        self.log_path = log_path
        self.csv_path = "performance.csv"
        self.config: dict = self.load_config()
        if not isinstance(self.config, dict):
            self.config = {"appearance_mode": "dark", "window_size": "900x600"}
        if "personality" not in self.config:
            self.config["personality"] = "Default"
        self.last_net_io = psutil.net_io_counters()
        self.last_net_time = time.time()
        # Explicit type hints to resolve lints
        self.history: Dict[str, List[float]] = {"cpu": [], "ram": [], "health": []}
        self.last_auto_backup = float(time.time())
        self.supported_exts = ['.py', '.json', '.md', '.log', '.png']
        self.event_history: List[Dict[str, str]] = [] 
        self.healed_registry: Dict[str, float] = {} # filename -> timestamp
        self.buffering_target_energy: float = 0.0 
        # Explicitly initialize as a list of dicts to satisfy linter
        goals_data: List[Dict[str, Any]] = [
            {"name": "Codebase Expansion", "target": 1000, "metric": "sloc"},
            {"name": "Feature Density", "target": 25, "metric": "files"}
        ]
        self.goals = goals_data
        self.init_csv()
        self.personality_quotes = self.config.get("personality_quotes", {
            "Default": ["System evolving as planned.", "Efficiency is the only law.", "Analyzing data structures...", "Optimization in progress."],
            "Aesthetic": ["Coding is poetry in motion.", "Visual harmony achieved.", "The interface breathes with purpose.", "Pixels aligned for perfection."],
            "Safety": ["Risk minimized. Stability is king.", "Check twice, write once.", "Redundancy is a virtue.", "Perimeter secure, scanning for anomalies."],
            "Performance": ["Vroom vroom. Processing at lightspeed.", "Optimal path discovered.", "Latency is the enemy.", "Turbo mode engaged."]
        })
        self.node_positions: Dict[str, tuple] = self.config.get("node_positions", {})
        self.current_anomalies: List[str] = []
        self.anomaly_buffer: List[bool] = []
        self.energy = 100.0
        self.last_energy_regen = time.time()

    def init_csv(self):
        if not os.path.exists(self.csv_path):
            with open(self.csv_path, "w", newline='') as f:
                writer = csv.writer(f)
                writer.writerow(["Timestamp", "CPU_%", "RAM_%", "Disk_%", "Net_Up_KBps", "Net_Down_KBps", "Code_Smells", "Persona"])

    def load_config(self):
        if os.path.exists(self.config_path):
            try:
                with open(self.config_path, "r") as f:
                    return json.load(f)
            except Exception:
                pass
        return {"appearance_mode": "dark", "window_size": "900x600"}

    def save_config(self, config):
        self.config = config
        with open(self.config_path, "w") as f:
            json.dump(self.config, f, indent=4)

    def get_system_stats(self):
        cpu = psutil.cpu_percent()
        ram = psutil.virtual_memory()
        disk = psutil.disk_usage('/')
        
        # Network calc
        now = time.time()
        curr_net_io = psutil.net_io_counters()
        dt = now - self.last_net_time
        
        up_speed = (curr_net_io.bytes_sent - self.last_net_io.bytes_sent) / dt
        down_speed = (curr_net_io.bytes_recv - self.last_net_io.bytes_recv) / dt
        
        self.last_net_io = curr_net_io
        self.last_net_time = now
        
        return {
            "cpu": cpu,
            "ram_percent": ram.percent,
            "ram_used_mb": ram.used // (1024**2),
            "ram_total_mb": ram.total // (1024**2),
            "disk_percent": disk.percent,
            "disk_free_gb": disk.free // (1024**3),
            "net_up_kb": up_speed / 1024,
            "net_down_kb": down_speed / 1024
        }
    
    def update_history(self, stats):
        self.history["cpu"].append(stats["cpu"])
        self.history["ram"].append(stats["ram_percent"])
        self.history["health"].append(float(stats.get("smells", 0)))
        if "energy" not in self.history: self.history["energy"] = []
        self.history["energy"].append(self.energy)
        
        # Max buffer size (50 samples)
        for key in self.history:
            if len(self.history[key]) > 50:
                self.history[key].pop(0)

    def count_sloc(self):
        total_lines = 0
        for root, dirs, files in os.walk("."):
            if ".venv" in dirs: dirs.remove(".venv")
            for file in files:
                if file.endswith(".py"):
                    try:
                        with open(os.path.join(root, file), "r", encoding="utf-8") as f:
                            total_lines += sum(1 for line in f if line.strip())
                    except Exception:
                        pass
        return total_lines

    def get_code_breakdown(self):
        # Explicit initialization to satisfy linter
        ext_list: List[str] = ['.py', '.json', '.md', '.log', '.png']
        res_dict: Dict[str, int] = {ext: 0 for ext in ext_list}
        for root, dirs, files in os.walk("."):
            if ".venv" in dirs: dirs.remove(".venv")
            for file in files:
                _, ext = os.path.splitext(file)
                if ext in res_dict:
                    val = res_dict[ext]
                    res_dict[ext] = val + 1
        return res_dict

    def get_heatmap_stats(self):
        # Returns [ (filename, sloc) ] for top 10 files
        stats = []
        for root, dirs, files in os.walk("."):
            if ".venv" in dirs: dirs.remove(".venv")
            for file in files:
                if file.endswith(".py"):
                    try:
                        fpath = os.path.join(root, file)
                        with open(fpath, "r", encoding="utf-8") as f:
                            sloc = sum(1 for line in f if line.strip())
                            stats.append((file, sloc))
                    except Exception: pass
        return sorted(stats, key=lambda x: x[1], reverse=True)[:10]

    def evolve_goals(self):
        sloc = self.count_sloc()
        p_stats = self.get_project_stats()
        
        evolved = False
        # Goal 0: SLOC
        if sloc >= self.goals[0]["target"] * 0.9:
            self.goals[0]["target"] = int(self.goals[0]["target"] * 1.5)
            self.add_event("GOAL", f"SLOC Target evolved to {self.goals[0]['target']}")
            evolved = True
            
        # Goal 1: Files
        if p_stats["files"] >= self.goals[1]["target"] * 0.9:
            self.goals[1]["target"] = int(self.goals[1]["target"] + 10)
            self.add_event("GOAL", f"File Target evolved to {self.goals[1]['target']}")
            evolved = True
            
        if evolved:
            self.speak("Evolution targets updated. The system is outgrowing its previous self.")
        return evolved

    def get_resource_limits(self):
        persona = self.config.get("personality", "Default")
        limits = {
            "Default": {"cpu_target": 80, "priority": "normal"},
            "Safety": {"cpu_target": 40, "priority": "below_normal"},
            "Performance": {"cpu_target": 95, "priority": "above_normal"},
            "Aesthetic": {"cpu_target": 60, "priority": "normal"}
        }
        return limits.get(persona, limits["Default"])

    def regenerate_energy(self):
        now = time.time()
        persona = self.config.get("personality", "Default")
        # Metabolic Multipliers
        multipliers = {
            "Performance": 2.2, # Turbo recovery
            "Default": 1.0,
            "Aesthetic": 1.5,
            "Safety": 0.6  # Measured, slow recovery
        }
        mult = multipliers.get(persona, 1.0)
        
        # Enhanced Harvesting: bonus if system is idle (Metabolic Surplus)
        stats = self.get_system_stats()
        if stats["cpu"] < 15.0:
            mult *= 2.0  # Double recovery if idle
        
        elapsed = now - self.last_energy_regen
        if elapsed > 30: # Check more frequently (30s)
            reg_amt = (elapsed / 60) * mult
            self.energy = min(100.0, self.energy + reg_amt)
            self.last_energy_regen = now
            # Persist metabolic interval for auto_runner
            self.config["metabolic_interval"] = self.get_metabolic_interval()
            self.save_config(self.config)

    def get_metabolic_interval(self):
        """Calculates adaptive heartbeat interval in minutes."""
        if self.energy < 20: return 15.0   # Deep Sleep (Metabolic Drought)
        if self.energy < 40: return 10.0   # Drowsy (Low Energy)
        
        persona = self.config.get("personality", "Default")
        if self.energy > 85 and persona == "Performance":
            return 2.0  # Hyper-active (Performance Burst)
            
        return 4.0      # Baseline

    def consume_energy(self, amount):
        if self.energy >= amount:
            self.energy -= amount
            # Immediate update of interval after drain
            self.config["metabolic_interval"] = self.get_metabolic_interval()
            self.save_config(self.config)
            return True
        return False

    def trigger_throttled_task(self, task_func, energy_cost=5):
        """Executes a task if local resources (CPU & Energy) allow."""
        self.regenerate_energy()
        limits = self.get_resource_limits()
        current_cpu = psutil.cpu_percent()
        
        # Combined check: CPU + Energy
        if current_cpu > limits["cpu_target"]:
            self.add_event("THROTTLE", f"Skipping task: CPU {current_cpu}% > {limits['cpu_target']}%")
            return False
        
        if self.energy < energy_cost:
            self.add_event("THROTTLE", f"Skipping task: Insufficient energy ({self.energy:.1f})")
            return False
            
        if self.consume_energy(energy_cost):
            return task_func()
        return False

    def get_project_tree(self):
        tree = []
        for root, dirs, files in os.walk("."):
            if ".venv" in dirs: dirs.remove(".venv")
            if "backups" in dirs: dirs.remove("backups")
            if "__pycache__" in dirs: dirs.remove("__pycache__")
            
            level = root.replace(".", "").count(os.sep)
            indent = "  " * level
            tree.append(f"{indent}📂 {os.path.basename(root) or '.'}/")
            sub_indent = "  " * (level + 1)
            for f in files:
                if f.endswith(('.py', '.json', '.md', '.log')):
                    tree.append(f"{sub_indent}📄 {f}")
        return "\n".join(tree)

    def get_personality_quote(self):
        import random
        persona = self.config.get("personality", "Default")
        quotes = self.personality_quotes.get(persona, self.personality_quotes["Default"])
        return random.choice(quotes)

    def update_personality_quotes(self, new_quotes: dict):
        self.personality_quotes = new_quotes
        self.config["personality_quotes"] = new_quotes
        self.save_config(self.config)
        self.add_event("CONFIG", "Personality quotes updated and persisted.")
        return True

    def get_health_forecast(self):
        data = self.history["health"]
        if len(data) < 10:
            return "Stable", "#AAAAAA"
        
        # Simple split comparison
        first_half = sum(data[:5]) / 5
        second_half = sum(data[-5:]) / 5
        delta = second_half - first_half
        
        if delta > 0.8:
            return "Degrading (High Risk)", "#FF4444"
        elif delta < -0.8:
            return "Improving (Stable)", "#00FFAA"
        else:
            return "Stable", "#666666"

    def get_connectivity_stats(self, limit=10):
        # Scan all .py files for imports
        counts = {}
        for root, dirs, files in os.walk("."):
            if ".venv" in dirs: dirs.remove(".venv")
            for file in files:
                if file.endswith(".py"):
                    try:
                        with open(os.path.join(root, file), "r", encoding="utf-8") as f:
                            for line in f:
                                line = line.strip()
                                if line.startswith("import ") or line.startswith("from "):
                                    parts = line.split()
                                    if len(parts) > 1:
                                        mod = parts[1].split(".")[0]
                                        counts[mod] = counts.get(mod, 0) + 1
                    except Exception: pass
        if limit:
            return sorted(counts.items(), key=lambda x: x[1], reverse=True)[:limit]
        return counts

    def get_heatmap_data(self):
        # Combines SLOC and Connectivity for all files
        conn = self.get_connectivity_stats(limit=None)
        heatmap = []
        for root, dirs, files in os.walk("."):
            if ".venv" in dirs: dirs.remove(".venv")
            for file in files:
                if file.endswith(".py"):
                    path = os.path.join(root, file)
                    sloc = self.count_sloc_for_file(path)
                    mod_name = file.replace(".py", "")
                    c_val = conn.get(mod_name, 0)
                    heatmap.append({"file": file, "sloc": sloc, "connectivity": c_val})
        return heatmap

    def count_sloc_for_file(self, path):
        try:
            with open(path, "r", encoding="utf-8") as f:
                return len([l for l in f if l.strip()])
        except: return 0

    def check_behavioral_anomalies(self, stats: dict):
        has_spike = stats['cpu'] > 90 or stats['ram_percent'] > 90
        self.anomaly_buffer.append(has_spike)
        if len(self.anomaly_buffer) > 10:
            self.anomaly_buffer.pop(0)
            
        if self.anomaly_buffer.count(True) >= 3:
            # Trigger voice alert based on persona
            persona = self.config.get("personality", "Default")
            warnings = {
                "Default": "Critical resource spike detected. Optimizing background tasks.",
                "Performance": "Resource maximum reached. Turbo mode sustaining high load.",
                "Safety": "EMERGENCY: Resource overflow. Initiating protective shutdown of non-essentials.",
                "Aesthetic": "Architectural pressure detected. Visual harmony is being compromised."
            }
            msg = warnings.get(persona, warnings["Default"])
            self.add_event("ANOMALY", msg)
            self.speak(msg)
            # Clear buffer to avoid spam
            self.anomaly_buffer = []
            return True
        return False

    def get_metabolic_score(self, file_path):
        """Calculates a 'Heat' index for a file: (SLOC * 0.3) + (Complexity * 0.7)."""
        try:
            with open(file_path, "r", encoding="utf-8") as f:
                content = f.read()
                sloc = len([l for l in content.splitlines() if l.strip()])
                # Heuristic complexity: count branches and loops
                complexity = len(re.findall(r"\b(if|elif|for|while|try|with|async)\b", content))
                
                # Connectivity factor from node Positions or standard mapping
                mod_name = os.path.basename(file_path).replace(".py", "")
                # Simple weight: engine > gui > app > others
                weights = {"system_engine": 5.0, "dashboard_gui": 3.0, "main_app": 2.0}
                conn_factor = weights.get(mod_name, 1.0)
                
                score = (sloc * 0.1) + (complexity * 1.5) * conn_factor
                return round(score, 2)
        except: return 0.0

    def check_code_health(self):
        issues = [] # List of tuples: (file, func, length, metabolic_score)
        activity = self.get_module_activity()
        
        for root, dirs, files in os.walk("."):
            if ".venv" in dirs: dirs.remove(".venv")
            for file in files:
                if file.endswith(".py"):
                    try:
                        path = os.path.join(root, file)
                        mod = file.replace(".py", "")
                        # Score includes Heat Scaling from V2.9 activity
                        m_score = self.get_metabolic_score(path) * (1.0 + activity.get(mod, 0.0))
                        
                        with open(path, "r", encoding="utf-8") as f:
                            lines = f.readlines()
                            func_start = -1
                            func_name = ""
                            for i, line in enumerate(lines):
                                stripped = line.lstrip()
                                if stripped.startswith("def "):
                                    if func_start != -1:
                                        length = i - func_start
                                        # Predictive threshold: lower threshold for high-heat hotspots
                                        if length > 35 or m_score > 60:
                                            issues.append((file, func_name, length, m_score))
                                    func_start = i
                                    func_name = stripped.split("(")[0].replace("def ", "").strip()
                            if func_start != -1:
                                length = len(lines) - func_start
                                if length > 35 or m_score > 60:
                                    issues.append((file, func_name, length, m_score))
                    except Exception: pass
        # Sort by metabolic score descending
        return sorted(issues, key=lambda x: x[3], reverse=True)

    def get_refactor_preview(self, issue):
        """Generates a high-fidelity modularization proposal."""
        try:
            if isinstance(issue, tuple):
                fname, func_name, length, m_score = issue
            else:
                parts = str(issue).split(":")
                fname = parts[0].strip()
                func_name = parts[1].split("(")[0].strip().split()[-1]
            
            with open(fname, "r", encoding="utf-8") as f:
                content = f.read()
                lines = content.splitlines()
            
            # Smart extraction (naive indent based)
            orig_lines = []
            found = False
            indent = ""
            for line in lines:
                if f"def {func_name}" in line:
                    found = True
                    indent = line[:line.find("def")]
                if found:
                    orig_lines.append(line)
                    if len(orig_lines) > 1 and line.strip() and not line.startswith(indent + " "):
                        if not line.strip().startswith("#") and not line.strip().startswith(")"):
                            break
            
            orig_text = "\n".join(orig_lines)
            
            # Predictive modularization proposal
            suggested = f"{indent}def {func_name}(self, *args, **kwargs):\n"
            suggested += f"{indent}    \"\"\"Refactored for optimal metabolic flow.\"\"\"\n"
            suggested += f"{indent}    # Predictive Split: Extracting logic to specialized sub-handlers\n"
            suggested += f"{indent}    self._optimized_logic_gate_1()\n"
            suggested += f"{indent}    self._optimized_logic_gate_2()\n\n"
            suggested += f"{indent}def _optimized_logic_gate_1(self):\n"
            suggested += f"{indent}    # TODO: Migrate core logic block A here\n"
            suggested += f"{indent}    pass\n\n"
            suggested += f"{indent}def _optimized_logic_gate_2(self):\n"
            suggested += f"{indent}    # TODO: Migrate core logic block B here\n"
            suggested += f"{indent}    pass\n"
            
            return orig_text, suggested
        except Exception as e:
            return f"Error: {e}", "Suggestion unavailable."

    def apply_refactor(self, fname, original, proposed):
        self.add_event("REFACTOR", f"Applying autonomous refactor to {fname}")
        try:
            # Safety backup before write
            self.perform_backup()
            
            with open(fname, "r", encoding="utf-8") as f:
                content = f.read()
            
            if original.strip() in content.strip():
                new_content = content.replace(original.strip(), proposed.strip())
                with open(fname, "w", encoding="utf-8") as f:
                    f.write(new_content)
                self.add_event("REFACTOR", f"Success: {fname} updated.")
                
                # Auto-commit if personality is Default or Safety
                persona = self.config.get("personality", "Default")
                if persona in ["Default", "Safety"]:
                    self.git_commit(f"Autonomous Refactor: Improved {os.path.basename(fname)}")
                    
                return True, "Refactor applied successfully."
            else:
                return False, "Could not match original code block in file."
        except Exception as e:
            self.add_event("ERROR", f"Refactor failed: {e}")
            return False, str(e)

    def run_self_tests(self):
        self.add_event("TEST", "Starting autonomous test suite")
        test_files = []
        for root, dirs, files in os.walk("."):
            if ".venv" in dirs: dirs.remove(".venv")
            for file in files:
                if (file.startswith("test_") or file.endswith("_test.py")) and file.endswith(".py"):
                    test_files.append(os.path.join(root, file))
        
        if not test_files:
            return {"status": "No Tests Found", "passed": 0, "total": 0}
            
        passed = 0
        total = len(test_files)
        for tf in test_files:
            try:
                # Simple execution check as a 'test'
                result = subprocess.run(["python", tf], capture_output=True, text=True, timeout=10)
                if result.returncode == 0:
                    passed += 1
            except Exception:
                pass
        
        summary = {"status": "Completed", "passed": passed, "total": total}
        self.add_event("TEST", f"Results: {passed}/{total} Passed")
        return summary

    def get_backup_list(self):
        backup_dir = "backups"
        if not os.path.exists(backup_dir): return []
        return sorted([f for f in os.listdir(backup_dir) if f.endswith(".zip")], reverse=True)

    def get_file_from_backup(self, zip_filename, arc_path):
        zip_path = os.path.join("backups", zip_filename)
        try:
            with zipfile.ZipFile(zip_path, 'r') as zipf:
                if arc_path in zipf.namelist():
                    return zipf.read(arc_path).decode('utf-8', errors='replace')
        except Exception: pass
        return "--- File not found in backup ---"

    def speak(self, text):
        # Use PowerShell SpeechSynthesizer for zero-dependency Windows TTS
        cmd = f"Add-Type -AssemblyName System.Speech; $synth = New-Object System.Speech.Synthesis.SpeechSynthesizer; $synth.Speak('{text}')"
        subprocess.Popen(["powershell", "-Command", cmd], 
                         stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

    def check_dependencies(self):
        missing = []
        # Simple scan of imports in project
        import re
        import importlib.util
        
        found_imports = set()
        for root, dirs, files in os.walk("."):
            if ".venv" in dirs: dirs.remove(".venv")
            for file in files:
                if file.endswith(".py"):
                    try:
                        with open(os.path.join(root, file), "r", encoding="utf-8") as f:
                            content = f.read()
                            # Find patterns like 'import pkg' or 'from pkg import ...'
                            matches = re.findall(r"^(?:import|from)\s+([a-zA-Z0-9_]+)", content, re.MULTILINE)
                            for m in matches: found_imports.add(m)
                    except Exception: pass
        
        # Check if they can be found
        std_libs = ["os", "sys", "time", "datetime", "json", "zipfile", "csv", "re", "subprocess", "importlib", "typing", "collections", "math", "random"]
        for pkg in found_imports:
            if pkg in std_libs or pkg == "system_engine" or pkg == "dashboard_gui": continue
            spec = importlib.util.find_spec(pkg)
            if spec is None:
                missing.append(pkg)
        return missing

    def install_dependency(self, pkg):
        self.add_event("HEAL", f"Attempting to install {pkg}")
        try:
            result = subprocess.run(["pip", "install", pkg], capture_output=True, text=True, timeout=60)
            if result.returncode == 0:
                self.add_event("HEAL", f"Successfully installed {pkg}")
                return True, result.stdout
            else:
                return False, result.stderr
        except Exception as e:
            return False, str(e)

    def trigger_docs(self):
        """Autonomous documentation sync: updates README based on current state."""
        self.add_event("DOCS", "Syncing autonomous documentation...")
        try:
            status = self.get_system_stats()
            # Simple README generation logic
            readme_content = f"# AI Autonomous Evolution Project\n\n## Status\n- **Uptime**: Active\n- **CPU**: {status['cpu']}%\n- **Energy**: {int(self.energy)}%\n- **Personality**: {self.config.get('personality', 'Default')}\n\n## Evolutionary Progress\nSystem is self-evolving under recursive autonomous guidance."
            with open("README.md", "w", encoding="utf-8") as f:
                f.write(readme_content)
            return True, "README.md updated"
        except Exception as e:
            return False, str(e)

    def get_performance_history_data(self):
        """Parses performance.csv for long-term trend analysis."""
        data = {"labels": [], "cpu": [], "ram": [], "smells": []}
        if not os.path.exists(self.csv_path): return data
        
        try:
            with open(self.csv_path, "r", newline='') as f:
                reader = csv.DictReader(f)
                rows = list(reader)
                
                # Sample the data to 30 points max for visualization
                if len(rows) > 30:
                    step = len(rows) // 30
                    rows = rows[::step]
                
                for row in rows:
                    # Clean timestamp for labels
                    try:
                        ts = row["Timestamp"].split(" ")[1][:5] # HH:MM
                        data["labels"].append(ts)
                        data["cpu"].append(float(row["CPU_%"]))
                        data["ram"].append(float(row["RAM_%"]))
                        data["smells"].append(float(row.get("Code_Smells", 0)))
                    except: continue
        except Exception as e:
            self.add_event("ERROR", f"Failed to parse CSV: {e}")
            
        return data

    def simulate_architectural_stress(self, extra_coupling: float, sloc_injection: int):
        """Non-destructive simulation of evolutionary stressors."""
        current_health = 10.0 # Excellent
        issues = self.check_code_health()
        current_health = max(0.0, 10.0 - len(issues))
        
        current_energy = self.energy
        history = {"health": [], "energy": []}
        
        # Simulation Parameters
        coupling_decay = extra_coupling * 0.1
        sloc_decay = sloc_injection / 1000.0
        
        sim_health = current_health
        sim_energy = current_energy
        
        for _ in range(60): # 60 virtual cycles
            # Health decays linearly with stress
            sim_health = max(0.0, sim_health - (coupling_decay + (sloc_decay * 0.05)))
            
            # Energy drain increases as health decreases
            drain_multiplier = 1.0 + (10.0 - sim_health) * 0.2
            base_drain = 0.5 + sloc_decay
            sim_energy = max(0.0, sim_energy - (base_drain * drain_multiplier))
            
            # Slow recovery if mode was Safety (hypothetically)
            if sim_health < 4: sim_energy += 0.2 # partial recovery simulation
            
            history["health"].append(sim_health * 10) # Scale to 100 for GUI
            history["energy"].append(sim_energy)
            
        return history

    def get_goal_status(self):
        sloc = self.count_sloc()
        files = self.get_project_stats()["files"]
        status = []
        for g in self.goals:
            current = float(sloc if g["metric"] == "sloc" else files)
            target = float(g["target"])
            status.append({
                "name": g["name"],
                "current": int(current),
                "target": int(target),
                "percent": min(1.0, current / target)
            })
        return status

    def generate_dependency_graph(self):
        nodes = set()
        edges = []
        for root, dirs, files in os.walk("."):
            if ".venv" in dirs: dirs.remove(".venv")
            for file in files:
                if file.endswith(".py"):
                    base = file.replace(".py", "")
                    nodes.add(base)
                    try:
                        with open(os.path.join(root, file), "r", encoding="utf-8") as f:
                            for line in f:
                                if line.startswith("import ") or line.startswith("from "):
                                    for target in nodes:
                                        if target in line and target != base:
                                            edges.append(f"  {base} --> {target}")
                    except Exception: pass
        
        mermaid = "graph TD\n" + "\n".join(set(edges))
        with open("dependency_graph.md", "w") as f:
            f.write(f"# Project Dependency Graph\n\n```mermaid\n{mermaid}\n```")
        self.add_event("ARCH", "Generated dependency graph")
        return "dependency_graph.md"

    def get_node_link_data(self):
        nodes = []
        links = []
        file_map = {}
        
        # 1. Identify all nodes (python files)
        for root, dirs, files in os.walk("."):
            if ".venv" in dirs: dirs.remove(".venv")
            for file in files:
                if file.endswith(".py"):
                    name = file.replace(".py", "")
                    path = os.path.join(root, file)
                    # Use standard count_sloc logic or a helper
                    try:
                        with open(path, "r", encoding="utf-8") as f:
                            sloc = sum(1 for line in f if line.strip())
                    except: sloc = 0
                    node_id = name
                    file_map[node_id] = path
                    nodes.append({"id": node_id, "sloc": sloc})
        
        # 2. Identify links (imports)
        for node in nodes:
            source = node["id"]
            path = file_map[source]
            try:
                with open(path, "r", encoding="utf-8") as f:
                    content = f.read()
                    for target_node in nodes:
                        target = target_node["id"]
                        if target != source and (f"import {target}" in content or f"from {target}" in content):
                            links.append({"source": source, "target": target})
            except: pass
            
        return {"nodes": nodes, "links": links}

    def optimize_visual_layout(self):
        """Autonomously rearranges nodes using a force-directed gravity algorithm."""
        data = self.get_node_link_data()
        nodes = data["nodes"]
        links = data["links"]
        
        # Parameters
        center_x, center_y = 450, 350
        iterations = 50
        repulsion_strength = 2000.0
        gravity_strength = 0.05
        
        # Initialize positions if missing
        for node in nodes:
            nid = node["id"]
            if nid not in self.node_positions:
                self.node_positions[nid] = (random.randint(100, 800), random.randint(100, 600))
        
        import math
        for _ in range(iterations):
            # Calculate forces for each node
            for node1 in nodes:
                nid1 = node1["id"]
                x1, y1 = self.node_positions[nid1]
                fx, fy = 0.0, 0.0
                
                # 1. Repulsion from other nodes
                for node2 in nodes:
                    nid2 = node2["id"]
                    if nid1 == nid2: continue
                    x2, y2 = self.node_positions[nid2]
                    dx, dy = x1 - x2, y1 - y2
                    dist_sq = dx*dx + dy*dy + 0.01
                    if dist_sq < 20000: # Interaction range
                        rep_f = repulsion_strength / dist_sq
                        fx += dx * rep_f
                        fy += dy * rep_f
                
                # 2. Gravity towards center (scaled by Metabolic Heat and Connectivity)
                # Foundational nodes move to center, peripheral move out
                m_score = self.get_metabolic_score(f"{nid1}.py") if os.path.exists(f"{nid1}.py") else 0
                conn = len([l for l in links if l["source"] == nid1 or l["target"] == nid1])
                weight = 1.0 + (m_score / 100.0) + (conn / 5.0)
                
                gdx, gdy = center_x - x1, center_y - y1
                fx += gdx * gravity_strength * weight
                fy += gdy * gravity_strength * weight
                
                # Apply forces with damping
                new_x = max(50, min(850, x1 + fx * 0.1))
                new_y = max(50, min(650, y1 + fy * 0.1))
                self.node_positions[nid1] = (new_x, new_y)
                
        # Persist results
        self.config["node_positions"] = self.node_positions
        self.save_config(self.config)
        self.add_event("ARCH", "Autonomous visual layout optimization complete.")
        return True


    def check_architectural_anomalies(self):
        """Scans for God Objects and Structural Erosion."""
        data = self.get_node_link_data()
        anomalies = []
        for node in data["nodes"]:
            nid = node["id"]
            sloc = node["sloc"]
            # Coupling: count how many links involve this node
            coupling = len([l for l in data["links"] if l["source"] == nid or l["target"] == nid])
            
            # God Object: Excessive size + centered
            if sloc > 800 and coupling > 4:
                anomalies.append(nid)
                self.add_event("ANOMALY", f"God Object detected: {nid} (SLOC:{sloc}, Coupling:{coupling})")
            # Tangled Dependency: excessive coupling regardless of size
            elif coupling > 6:
                anomalies.append(nid)
                self.add_event("ANOMALY", f"High Coupling Erosion: {nid} (Coupling:{coupling})")
        self.current_anomalies = anomalies
        return anomalies

    def get_impact_propagation_path(self, node_id: str):
        """Recursively finds all modules that depend on node_id (Downstream)."""
        data = self.get_node_link_data()
        links = data["links"]
        
        impacted = {} # nid -> distance
        queue = [(node_id, 0)]
        
        while queue:
            curr, dist = queue.pop(0)
            if curr in impacted and impacted[curr] <= dist:
                continue
            
            impacted[curr] = dist
            
            # Find all nodes that depend on 'curr' (source depends on target in our links)
            # Actually, our links are {"source": file, "target": imported_module}
            # So if file 'A' imports 'B', source=A, target=B.
            # Downstream items for B are all sources where target=B.
            for link in links:
                if link["target"] == curr:
                    queue.append((link["source"], dist + 1))
        
        # Remove self from impact list (or keep with dist 0)
        return impacted

    def auto_regulate_personality(self):
        """Self-regulating behavioral adaptation based on health and energy."""
        if not self.config.get("auto_regulate", False): return False
        
        smells = len(self.check_code_health())
        current_persona = self.config.get("personality", "Default")
        new_persona = current_persona
        
        # Priority 1: Emergency Safety (Low energy or high tech debt)
        if self.energy < 25 or smells > 6:
            new_persona = "Safety"
        # Priority 2: Peak Performance (High energy and clean code)
        elif self.energy > 85 and smells == 0:
            new_persona = "Performance"
        # Priority 3: Aesthetic refinement (Good energy, moderate health)
        elif self.energy > 60 and 0 < smells < 3:
            new_persona = "Aesthetic"
        
        if new_persona != current_persona:
            self.config["personality"] = new_persona
            self.save_config(self.config)
            self.add_event("ADAPT", f"Autonomous Strategy Shift: {current_persona} -> {new_persona} (Energy:{int(self.energy)}%, Smells:{smells})")
            self.speak(f"Adapting operational strategy to {new_persona} for optimal stability.")
            return True
        return False

    def evolve_test_suite(self):
        """Autonomous logic hardening: generates tests for anomalous modules."""
        if not self.current_anomalies: return False
        
        target = self.current_anomalies[0]
        target_file = f"{target}.py"
        if not os.path.exists(target_file): return False
        
        try:
            with open(target_file, "r", encoding="utf-8") as f:
                content = f.read()
            import re
            methods = re.findall(r"def\s+([a-zA-Z_0-9]+)\(self", content)
            if not methods: return False
            
            # 1. Heuristic Branch Capture: Look for "self.energy < X" or "sloc > X"
            # Flexible regex to catch both if-statements and variable assignments with optional floats
            branch_match = re.search(r"(?:self\.energy|self\.energy_critical|energy)\s*[<>]=?\s*(\d+(?:\.\d+)?)", content)
            deep_logic = ""
            if branch_match:
                try:
                    threshold = float(branch_match.group(1))
                    val_to_test = threshold - 1.0 if "<" in branch_match.group(0) else threshold + 1.0
                    deep_logic = f"""
        # Logic Mirroring: Stimulating branch related to threshold '{threshold}'
        self.engine.energy = {val_to_test}
        status, _ = self.engine.get_predictive_load_status()
        results.append({{"name": "{target} Branch Logic (Val: {val_to_test})", "status": "PASS" if status != "STABLE" else "FAIL"}})
        """
                except: pass

            # Pick a method to "harden"
            method_to_test = random.choice(methods)
            if method_to_test.startswith("__"): return False 
            
            test_name = f"test_gen_{target}_{method_to_test}"
            test_file = "test_engine_logic.py"
            if not os.path.exists(test_file): return False
            
            with open(test_file, "r") as f:
                suite_content = f.read()
            if test_name in suite_content: return False
            
            test_code = f"""
    def {test_name}(self):
        \"\"\"Autogenerated Logic Mirror for {target}.{method_to_test}\"\"\"
        results = []
        # Basic reachability check
        results.append({{"name": "{test_name} (Reachability)", "status": "PASS"}})
        {deep_logic}
        return results
"""
            
            lines = suite_content.splitlines(keepends=True)
            insert_idx = -1
            for i, line in enumerate(lines):
                if 'if __name__ == "__main__":' in line:
                    insert_idx = i - 1
                    break
            
            if insert_idx != -1:
                lines.insert(insert_idx, test_code)
                # Inject call in __main__
                for i, line in enumerate(lines):
                    if 'final_report["tests"].extend(suite.test_look_ahead_buffer())' in line:
                        lines.insert(i + 1, f'        final_report["tests"].extend(suite.{test_name}())\n')
                        break
                
                with open(test_file, "w") as f:
                    f.writelines(lines)
                
                self.add_event("EVO_TEST", f"Generated Deep Logic Mirror: {test_name}")
                return True
        except Exception as e:
            self.add_event("ERROR", f"Test evolution failed: {e}")
        return False

    def get_project_stats(self):
        file_count = 0
        dir_count = 0
        for root, dirs, files in os.walk("."):
            if ".venv" in dirs:
                dirs.remove(".venv")
            file_count += len(files)
            dir_count += len(dirs)
        return {"files": file_count, "dirs": dir_count}

    def append_log(self, message):
        timestamp = time.strftime('%H:%M:%S')
        log_entry = f"[{timestamp}] {message}\n"
        with open(self.log_path, "a") as f:
            f.write(log_entry)
        return log_entry

    def add_event(self, event_type, msg):
        event = {
            "time": datetime.now().strftime("%H:%M:%S"),
            "type": event_type,
            "msg": msg
        }
        self.event_history.insert(0, event)
        if len(self.event_history) > 50:
            self.event_history.pop()
        self.append_log(f"EVENT [{event_type}]: {msg}")

    def load_logs(self, limit=100):
        if os.path.exists(self.log_path):
            with open(self.log_path, "r") as f:
                content = f.read()
                raw_lines = content.splitlines()
                lines = raw_lines[max(0, len(raw_lines) - int(limit)):]
                return "\n".join(lines) + "\n" if lines else ""
        return "--- No previous logs found ---\n"

    def perform_backup(self, reason="Manual"):
        backup_dir = "backups"
        if not os.path.exists(backup_dir):
            os.makedirs(backup_dir)
        
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"{backup_dir}/evolution_backup_{timestamp}.zip"
        
        # Prepare Semantic DNA Metadata
        sloc = self.count_sloc()
        issues = self.check_code_health()
        metadata = {
            "timestamp": timestamp,
            "reason": reason,
            "personality": self.config.get("personality", "Default"),
            "energy": self.energy,
            "sloc": sloc,
            "smells": len(issues),
            "version": "3.1"
        }
        meta_path = "dna_metadata.json"
        
        try:
            # Write temp metadata file
            with open(meta_path, "w") as f:
                json.dump(metadata, f, indent=4)
                
            with zipfile.ZipFile(filename, 'w', zipfile.ZIP_DEFLATED) as zipf:
                # Add metadata first
                zipf.write(meta_path, "dna_metadata.json")
                
                for root, dirs, files in os.walk("."):
                    if ".venv" in dirs: dirs.remove(".venv")
                    if "backups" in dirs: dirs.remove("backups")
                    if "snapshots" in dirs: dirs.remove("snapshots")
                    if "__pycache__" in dirs: dirs.remove("__pycache__")
                    
                    for file in files:
                        if file.endswith(('.py', '.json', '.log', '.md')) and file != meta_path:
                            file_path = os.path.join(root, file)
                            arcname = os.path.relpath(file_path, ".")
                            zipf.write(file_path, arcname)
            
            if os.path.exists(meta_path): os.remove(meta_path)
            self.add_event("BACKUP", f"Semantic DNA Snapshot created: {os.path.basename(filename)} (Reason: {reason})")
            return True, filename
        except Exception as e:
            if os.path.exists(meta_path): os.remove(meta_path)
            return False, str(e)

    def get_backup_metadata(self, zip_filename):
        """Extracts the DNA metadata from a specific backup ZIP."""
        zip_path = os.path.join("backups", zip_filename)
        try:
            with zipfile.ZipFile(zip_path, 'r') as zipf:
                if "dna_metadata.json" in zipf.namelist():
                    return json.loads(zipf.read("dna_metadata.json").decode('utf-8'))
        except Exception: pass
        return None

    def rollback_to_snapshot(self, zip_filename):
        """Autonomously restores the project state from a selected snapshot."""
        zip_path = os.path.join("backups", zip_filename)
        if not os.path.exists(zip_path): return False, "Snapshot not found."
        
        self.add_event("ROLLBACK", f"Initiating project restoration from {zip_filename}...")
        try:
            with zipfile.ZipFile(zip_path, 'r') as zipf:
                # Simple extraction (overwrite existing)
                for item in zipf.namelist():
                    if item == "dna_metadata.json": continue
                    zipf.extract(item, ".")
            self.add_event("ROLLBACK", "Restoration complete. System DNA stabilized.")
            return True, "State successfully restored."
        except Exception as e:
            self.add_event("ERROR", f"Rollback failed: {e}")
            return False, str(e)

    def log_performance_csv(self, stats):
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        with open(self.csv_path, "a", newline='') as f:
            writer = csv.writer(f)
            writer.writerow([
                timestamp, 
                stats["cpu"], 
                stats["ram_percent"], 
                stats["disk_percent"], 
                f"{stats['net_up_kb']:.2f}", 
                f"{stats['net_down_kb']:.2f}",
                stats.get("smells", 0),
                self.config.get("personality", "Default")
            ])

    def optimize_strategy_thresholds(self):
        """Analyzes CSV to find which personalities are most efficient and adjusts config."""
        if not os.path.exists(self.csv_path): return None
        
        persona_stats = {} # name -> {smell_reduction: total, count: N, metabolism: total}
        
        try:
            with open(self.csv_path, "r") as f:
                reader = csv.DictReader(f)
                last_smells = None
                for row in reader:
                    persona = row.get("Persona", "Default")
                    try:
                        curr_smells = float(row.get("Code_Smells", 0))
                        cpu = float(row.get("CPU_%", 0))
                        ram = float(row.get("RAM_%", 0))
                        metabolism = cpu + ram
                        
                        if persona not in persona_stats:
                            persona_stats[persona] = {"reduction": 0.0, "count": 0, "metabolism": 0.0}
                        
                        if last_smells is not None:
                            reduction = max(0.0, last_smells - curr_smells)
                            persona_stats[persona]["reduction"] += reduction
                        
                        persona_stats[persona]["metabolism"] += metabolism
                        persona_stats[persona]["count"] += 1
                        last_smells = curr_smells
                    except: continue
        except: return None
        
        # Calculate Efficiency (Reduction per Metabolism point)
        best_persona = "Default"
        max_efficiency = -1.0
        efficiencies = {}
        
        for p, s in persona_stats.items():
            if s["count"] == 0: continue
            eff = s["reduction"] / (s["metabolism"] / s["count"] + 0.1) # avoid div zero
            efficiencies[p] = eff
            if eff > max_efficiency:
                max_efficiency = eff
                best_persona = p
        
        # Adjust thresholds based on best performer
        # Example: If 'Performance' is most efficient, lower its entry energy threshold
        if "strategy_overrides" not in self.config:
            self.config["strategy_overrides"] = {}
            
        old_val = self.config["strategy_overrides"].get(f"{best_persona}_efficiency", 1.0)
        self.config["strategy_overrides"][f"{best_persona}_efficiency"] = max_efficiency
        self.save_config(self.config)
        
        self.add_event("META_EVO", f"Strategy Evolved: {best_persona} identified as most efficient (Eff:{max_efficiency:.2f}).")
        return {"best": best_persona, "efficiencies": efficiencies}

    def trigger_throttled_task(self, task_func, energy_cost):
        """Proactively checks for metabolic headroom before execution."""
        if self.energy < energy_cost:
            # Not enough energy for even one execution
            self.buffering_target_energy = energy_cost * 2.0
            return False
            
        if self.buffering_target_energy > 0:
            if self.energy < self.buffering_target_energy:
                # Still in buffering mode
                return False
            else:
                # Buffer achieved!
                self.buffering_target_energy = 0.0

        # Survival Margin: Ensure we have at least 10 units left for OS/Watchdog stability
        if self.energy - energy_cost < 10.0:
            self.buffering_target_energy = energy_cost + 15.0
            self.add_event("METABOLISM", f"Entering BUFFERING mode to sustain {task_func.__name__}")
            return False

        # Proceed with task
        self.energy -= energy_cost
        task_func()
        return True

    def cleanup_old_data(self, days=1):
        backup_dir = "backups"
        if not os.path.exists(backup_dir):
            return 0
        
        count = 0
        now = time.time()
        for f in os.listdir(backup_dir):
            f_path = os.path.join(backup_dir, f)
            if os.path.isfile(f_path) and f.endswith(".zip"):
                if os.stat(f_path).st_mtime < now - (days * 86400):
                    try:
                        os.remove(f_path)
                        count += 1
                    except Exception:
                        pass
        if count > 0:
            self.add_event("CLEANUP", f"Removed {count} old backups")
        return count

    def generate_evolution_report(self):
        report_path = "evolution_report.md"
        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        
        # Stats from CSV
        avg_cpu = 0
        avg_ram = 0
        recorded_points = 0
        if os.path.exists(self.csv_path):
            with open(self.csv_path, "r") as f:
                reader = csv.DictReader(f)
                cpu_vals = []
                ram_vals = []
                for row in reader:
                    try:
                        cpu_vals.append(float(row["CPU_%"]))
                        ram_vals.append(float(row["RAM_%"]))
                    except Exception: pass
                if cpu_vals:
                    avg_cpu = sum(cpu_vals) / len(cpu_vals)
                    avg_ram = sum(ram_vals) / len(ram_vals)
                    recorded_points = len(cpu_vals)

        # Stats from project
        p_stats = self.get_project_stats()
        sloc = self.count_sloc()
        
        # Count backups
        backup_count = 0
        if os.path.exists("backups"):
            backup_count = len([f for f in os.listdir("backups") if f.endswith(".zip")])

        report_content = f"""# AI Evolution Report
Generated at: {now}

## 🚀 Performance Overview (Last {recorded_points} minutes)
- **Average CPU Usage:** {avg_cpu:.2f}%
- **Average RAM Usage:** {avg_ram:.2f}%
- **Data Points Collected:** {recorded_points}

## 📂 Project Statistics
- **Total Files:** {p_stats['files']}
- **Total Directories:** {p_stats['dirs']}
- **Source Lines of Code (SLOC):** {sloc}
- **Stored Backups:** {backup_count}

## 📝 Recent Activity Summary
The system has been autonomously evolving. Check `app.log` for granular event details.

---
*Generated autonomously by Evolution Engine v2.0*
"""
        with open(report_path, "w", encoding="utf-8") as f:
            f.write(report_content)
        self.add_event("REPORT", "Generated new evolution report")
        return report_path

    def git_commit(self, message=None):
        if not os.path.exists(".git"):
            return False, "Not a git repository."
        
        if message is None:
            # Autonomous message generation
            p_stats = self.get_project_stats()
            health = self.get_health_forecast()[0]
            timestamp = datetime.now().strftime("%H:%M:%S")
            message = f"Autonomous Evolution Step [{timestamp}] | Files: {p_stats['files']} | Health: {health}"
            
        try:
            subprocess.run(["git", "add", "."], check=True)
            subprocess.run(["git", "commit", "-m", message], check=True)
            self.add_event("GIT", f"Committed: {message}")
            return True, f"Changes committed: {message}"
        except Exception as e:
            self.add_event("ERROR", f"Git commit failed: {e}")
            return False, str(e)

    def save_ui_snapshot(self, x, y, w, h):
        snap_dir = "snapshots"
        if not os.path.exists(snap_dir):
            os.makedirs(snap_dir)
        
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        fname = os.path.join(snap_dir, f"evolution_{timestamp}.png")
        try:
            # Region: (left, top, width, height)
            pyautogui.screenshot(fname, region=(x, y, w, h))
            self.add_event("SNAPSHOT", f"UI State archived: {os.path.basename(fname)}")
            return True, fname
        except Exception as e:
            self.add_event("ERROR", f"Snapshot failed: {e}")
            return False, str(e)

    def get_history_snapshots(self):
        snap_dir = "snapshots"
        if not os.path.exists(snap_dir):
            return []
        
        snaps = []
        for f in os.listdir(snap_dir):
            if f.endswith(".png"):
                path = os.path.join(snap_dir, f)
                # Filename format: evolution_20260327_024542.png
                try:
                    ts_str = f.replace("evolution_", "").replace(".png", "")
                    # 20260327_024542 -> readable
                    dt = datetime.strptime(ts_str, "%Y%m%d_%H%M%S")
                    snaps.append({
                        "path": os.path.abspath(path),
                        "time": dt.strftime("%Y-%m-%d %H:%M:%S"),
                        "raw_time": ts_str
                    })
                except: continue
        
        # Sort by time
        snaps.sort(key=lambda x: x["raw_time"])
        return snaps

    def fix_common_bugs(self):
        """Autonomously scans and repairs frequent codebase anomalies."""
        repaired = []
        # Pattern 1: Missing float cast for canvas ops
        for root, dirs, files in os.walk("."):
            if ".venv" in dirs: dirs.remove(".venv")
            for file in files:
                if file.endswith(".py"):
                    path = os.path.join(root, file)
                    try:
                        with open(path, "r", encoding="utf-8") as f:
                            content = f.read()
                        
                        modified = content
                        # Replace generic int grid with float for better coordinate math
                        if "x_off, y_off = 20, 20" in modified:
                            modified = modified.replace("x_off, y_off = 20, 20", "x_off, y_off = 20.0, 20.0")
                        
                        if modified != content:
                            with open(path, "w", encoding="utf-8") as f:
                                f.write(modified)
                            repaired.append(f"Standardized offsets in {file}")
                            self.healed_registry[file] = time.time()
                    except: pass
        
        if repaired:
            self.add_event("HEAL", f"Self-Correction applied: {', '.join(repaired)}")
        return repaired

    def get_predictive_load_status(self):
        """Predicts future workload and suggests resource conservation."""
        # 1. Analyze energy trend
        energy_critical = self.energy < 25.0
        
        # 2. Analyze proximity to evolution goals
        goals = self.get_goal_status()
        near_goal = any(g["percent"] > 0.85 for g in goals)
        
        # 3. Analyze recent activity
        recent_events = self.event_history[-10:]
        high_activity = len([e for e in recent_events if e["type"] in ["BACKUP", "REFACTOR", "ARCH"]]) > 4
        
        if (energy_critical or high_activity) and near_goal:
            return "THROTTLE_PREDICTIVE", "Metabolic preservation for upcoming milestone."
        elif energy_critical:
            return "CONSERVE", "Low energy. Background tasks slowed."
        
        return "STABLE", "Resources optimal."

    def run_autonomous_tests(self):
        """Triggers the logic verification sub-process."""
        try:
            import subprocess
            subprocess.Popen([sys.executable, "test_engine_logic.py"])
            self.add_event("TEST", "Autonomous logic verification sequence triggered.")
            return True
        except Exception as e:
            self.add_event("ERROR", f"Failed to trigger tests: {e}")
            return False

    def update_node_position(self, node_id, x, y):
        """Persists custom architectural layout coordinates."""
        self.node_positions[node_id] = (x, y)
        self.config["node_positions"] = self.node_positions
        self.save_config(self.config)
        return True

    def get_module_activity(self):
        """Returns normalized activity scores (0-1) for all modules based on heat and events."""
        heatmap = self.get_heatmap_data()
        activity = {}
        recent_evs = [e["type"] for e in self.event_history[-10:]]
        
        for item in heatmap:
            mod = str(item["file"]).replace(".py", "")
            # Base activity from metabolic heat
            m_score = self.get_metabolic_score(os.path.join(".", item["file"]))
            base = min(1.0, m_score / 500.0)
            
            # Bonus activity if module is frequently involved in recent events
            event_bonus = 0.2 if any(mod in str(e) for e in self.event_history[-5:]) else 0.0
            
            activity[mod] = min(1.0, base + event_bonus)
        return activity

