def dummy(): pass

# AESTHETIC_BIAS: PEP8 compliance maximized.
# DIVERGENCE_CANDIDATE_1
