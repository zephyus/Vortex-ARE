import pyautogui
import pyperclip
import time
import keyboard
import sys
import os
import psutil
import subprocess

PROMPT = """[System Auto-Tick: Autonomous Development Mode]
請繼續進行 Windows 程式專案的自動化開發與自我演化。目前使用者正在休息，系統處於無人值守模式。請完全自主運作，並遵循以下步驟：

1. **狀態感知 (Assess & Read)**：檢視目前的專案狀態、讀取最近修改的檔案，確認前一回合的程式碼是否成功寫入，或是終端機有報錯需要處理。
2. **自主演化 (Determine Next Objective)**：身為一個資深開發者，請自主決定專案下一步的最佳發展方向（例如：實作新功能、改善 UI 元件、重構程式碼結構、添加單元測試、或是進行效能優化）。
3. **果斷執行 (Execute)**：使用你的寫檔/改檔工具實作你的想法。若需要執行終端機指令（如啟動測試、安裝套件）來驗證程式碼，請在你認為安全的前提下，自行將指令設定為可以自動執行（SafeToAutoRun=true），以維持自動化流程不被中斷。
4. **自我修復 (Self-Correction)**：若發現任何 Bug 或錯誤，請將「修復錯誤」作為最高優先級，主動追蹤 log 並修正。
5. **進度報告 (Report)**：在回答的最後，請用簡短的條列式重點總結：(1) 這回合完成了什麼 (2) 下個回合準備做什麼。

⚠️ **最高原則**：我是自動化腳本，無法回答你的任何提問。遇到任何設計抉擇或技術困難，請依你的專業知識做出「最佳判斷」並直接執行。不要徵求許可，請直接開始這回合的工作！"""

def main():
    print("=========================================")
    print("🤖 Antigravity 睡前自動化掛機機器人 啟動！(升級影像辨識版)")
    print("=========================================\n")
    
    # 步驟 1：取得輸入框座標
    print("【第一步】請將滑鼠游標移動到右側的「文字輸入框」上，然後按下鍵盤的【F8】不要動。")
    keyboard.wait('f8')
    input_x, input_y = pyautogui.position()
    print(f"✅ 已鎖定輸入框位置: 座標 ({input_x}, {input_y})\n")
    
    time.sleep(0.5)

    # 步驟 2：取得藍色按鈕座標
    print("【第二步】請將滑鼠游標移動到右下角「藍色的執行按鈕 (箭頭)」上，然後按下鍵盤的【F9】不要動。")
    keyboard.wait('f9')
    btn_x, btn_y = pyautogui.position()
    print(f"✅ 已鎖定按鈕位置: 座標 ({btn_x}, {btn_y})\n")
    
    time.sleep(0.5)

    # 步驟 3：影像擷取 Always Run 座標
    print("【第三步】無敵影像辨識模式 (破解會一直換位置的 Always run)：")
    print("就算終端機畫面會上下捲動也沒關係，腳本會自動掃描整個螢幕尋找按鈕的字樣！")
    print("請將滑鼠游標停在畫面上「Always run」按鈕的**正中央**，然後按下【F10】，腳本會對這個按鈕原地拍照。")
    print("（如果找不到，或不想開啟防護，可以直接按【ESC】跳過這步）")
    
    always_run_enabled = False
    while True:
        if keyboard.is_pressed('f10'):
            ax, ay = pyautogui.position()
            print(f"📸 正在擷取座標 ({ax}, {ay}) 的按鈕影像...")
            
            # 將滑鼠自動移開，以免框框有滑鼠移上去的「反白變色」特效，導致後續認不出平常的按鈕
            pyautogui.moveTo(10, 10)
            time.sleep(0.5)
            
            # 擷取按鈕周圍 100x40 像素的畫面
            left = int(ax - 50)
            top = int(ay - 20)
            try:
                img = pyautogui.screenshot(region=(left, top, 100, 40))
                img.save("always_run_template.png")
                always_run_enabled = True
                print("✅ 拍照成功！已完美保存按鈕的原貌 (always_run_template.png)。")
                print("🌟 稍後程式每次貼上指令後，會進入『全自動鷹眼模式』，只要按鈕出現在螢幕內就會秒點掉！\n")
            except Exception as e:
                print(f"❌ 截圖失敗: {e}")
            break
        if keyboard.is_pressed('esc') or keyboard.is_pressed('enter'):
            print("⏭️ 已跳過 Always run 設定。\n")
            break
        time.sleep(0.05)
        
    time.sleep(0.5)

    # 步驟 4：設定間隔時間
    print("【第四步】請設定自動執行的間隔時間（分鐘）。強烈建議設定 3 到 5 分鐘。")
    user_input = input("⏳ 請輸入間隔分鐘數 (直接按 Enter 預設為 4 分鐘): ")
    try:
        interval_minutes = float(user_input) if user_input.strip() else 4.0
    except ValueError:
        print("輸入無效的數字，將使用預設值 4 分鐘。")
        interval_minutes = 4.0
        
    interval_seconds = interval_minutes * 60

    print(f"\n==============================================")
    print(f"🚀 掛機腳本已正式啟動！每 {interval_minutes} 分鐘會自動發送一次 Prompt。")
    print(f"【緊急停止方法】：隨時按住鍵盤左上角的【ESC】鍵即可停止程式！")
    print(f"現在您可以將畫面切換至 Antigravity 並安心去睡覺了。晚安！")
    print(f"==============================================\n")

    # 將要發送的文字複製到剪貼簿 (避免中文直接用 typewrite 產生亂碼)
    pyperclip.copy(PROMPT)
    time.sleep(2)

    def is_app_running():
        for proc in psutil.process_iter(['name', 'cmdline']):
            try:
                if proc.info['name'] in ['python.exe', 'pythonw.exe']:
                    if any('main_app.py' in cmd for cmd in proc.info['cmdline'] if cmd):
                        return True
            except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess): pass
        return False

    def start_app():
        pythonw = os.path.join(".venv", "Scripts", "pythonw.exe")
        if not os.path.exists(pythonw): pythonw = "pythonw"
        subprocess.Popen([pythonw, "main_app.py"])

    try:
        while True:
            # Watchdog Guard
            if not is_app_running():
                print(f"[{time.strftime('%H:%M:%S')}] 🛡️ Dashboard not found. Respawning...")
                start_app()
                time.sleep(3)

            current_time = time.strftime('%H:%M:%S')
            print(f"[{current_time}] 觸發心跳：正在發送自動指令...")
            
            # 確保剪貼簿內容正確（防止被其他程式覆蓋）
            pyperclip.copy(PROMPT)
            time.sleep(0.3)
            
            # 1. 點擊輸入框獲得焦點
            pyautogui.click(x=input_x, y=input_y)
            time.sleep(0.8) # 增加等待時間讓視窗完全聚焦
            
            # 2. 清空輸入框 (Ctrl+A -> Backspace) 確保不會跟舊文字疊在一起
            pyautogui.hotkey('ctrl', 'a')
            time.sleep(0.2)
            pyautogui.press('backspace')
            time.sleep(0.2)
            
            # 3. 貼上 (Ctrl+V)
            pyautogui.hotkey('ctrl', 'v')
            time.sleep(0.8) # 增加等待時間讓文字填入
            
            # 4. 點擊藍色送出按鈕
            pyautogui.click(x=btn_x, y=btn_y)
            
            print(f"[{current_time}] 指令發送完成。等待 {interval_minutes} 分鐘...\n")
            
            counter = 0
            for _ in range(int(interval_seconds * 10)):
                if keyboard.is_pressed('esc'):
                    print("\n🛑 偵測到 ESC 鍵，自動化腳本已終止。")
                    sys.exit(0)
                
                # 自動掃描畫面並點擊 Always Run
                # confidence=0.8 可以容許解析度或色彩微小變化
                if always_run_enabled and counter > 0 and counter % 50 == 0:
                    try:
                        pos = pyautogui.locateCenterOnScreen('always_run_template.png', confidence=0.8)
                        if pos:
                            print(f"\n[自動防護] 鷹眼發現 Always run 按鈕出現在 {pos}，火速放行！")
                            # 點選 Always Run
                            pyautogui.click(pos)
                            time.sleep(0.2)
                            # 預防萬一，點選 Always run 裡面的 "Always run" (對於下拉選單)
                            # 如果它是一個下拉式選單，點了之後可能會在下方展開另一個按鈕
                            # 但我們這裡先假定點一次就夠了
                            
                            # 點完切回文字框，避免影響下一次貼上
                            pyautogui.click(x=input_x, y=input_y)
                    except Exception:
                        # 這是 pyautogui 在找不到影像時會拋出的 Error，代表目前畫面無攔截按鈕，可直接略過
                        pass
                    
                counter += 1
                time.sleep(0.1)
                
    except KeyboardInterrupt:
        print("\n🛑 程式已手動中斷。")

if __name__ == "__main__":
    main()
