import customtkinter as ctk
from system_engine import SystemEngine
import time
import os
import random

class EvolutionDashboard(ctk.CTk):
    def __init__(self, engine: SystemEngine):
        super().__init__()
        self.engine = engine
        
        # UI Setup
        self.title("AI Autonomous Evolution Dashboard v2.0")
        self.geometry(self.engine.config.get("window_size", "900x600"))
        ctk.set_appearance_mode(self.engine.config.get("appearance_mode", "dark"))
        
        # Layout
        self.grid_rowconfigure(0, weight=1)
        self.grid_columnconfigure(1, weight=1)
        
        # Sidebar
        self.setup_sidebar()
        
        # Main Area
        self.setup_main_area()
        
        # Start Loops
        self.last_csv_log = time.time()
        self.last_dep_check: float = 0.0
        self.anomaly_count = 0
        self.update_personality_theme(self.engine.config.get("personality", "Default"))
        self.update_loop()
        self.engine.append_log("GUI Initialized / System Engaged")

    def setup_sidebar(self):
        self.navigation_frame = ctk.CTkFrame(self, corner_radius=0)
        self.navigation_frame.grid(row=0, column=0, sticky="nsew")
        
        self.nav_label = ctk.CTkLabel(self.navigation_frame, text="EVOLUTION OS", font=ctk.CTkFont(size=20, weight="bold"))
        self.nav_label.grid(row=0, column=0, padx=20, pady=20)
        
        self.theme_btn = ctk.CTkButton(self.navigation_frame, text="Toggle Theme", command=self.toggle_theme)
        self.theme_btn.grid(row=1, column=0, padx=10, pady=10)
        
        self.personality_label = ctk.CTkLabel(self.navigation_frame, text="EVO Strategy", font=ctk.CTkFont(size=12))
        self.personality_label.grid(row=2, column=0, pady=(10, 0))
        self.personality_menu = ctk.CTkOptionMenu(self.navigation_frame, values=["Default", "Performance", "Safety", "Aesthetic"], command=self.change_personality)
        self.personality_menu.set(self.engine.config.get("personality", "Default"))
        self.personality_menu.grid(row=3, column=0, padx=10, pady=(0, 10))
        
        self.cleanup_btn = ctk.CTkButton(self.navigation_frame, text="System Cleanup", command=self.trigger_cleanup, fg_color="#A371F7", hover_color="#8A5BDE")
        self.cleanup_btn.grid(row=3, column=0, padx=10, pady=10)
        
        self.backup_btn = ctk.CTkButton(self.navigation_frame, text="Manual Backup", command=self.trigger_backup, fg_color="#2EA44F", hover_color="#22863A")
        self.backup_btn.grid(row=4, column=0, padx=10, pady=10)
        
        self.report_btn = ctk.CTkButton(self.navigation_frame, text="Gen Evolution Report", command=self.trigger_report, fg_color="#FF5F1F", hover_color="#E6551A")
        self.report_btn.grid(row=5, column=0, padx=10, pady=10)
        
        self.doc_btn = ctk.CTkButton(self.navigation_frame, text="Sync Documentation", command=self.trigger_docs, fg_color="#1FA56A", hover_color="#147048")
        self.doc_btn.grid(row=6, column=0, padx=10, pady=10)
        
        self.insights_btn = ctk.CTkButton(self.navigation_frame, text="Codebase Insights", command=self.open_insights, fg_color="#A56A1F", hover_color="#704814")
        self.insights_btn.grid(row=7, column=0, padx=10, pady=10)
        
        self.arch_btn = ctk.CTkButton(self.navigation_frame, text="Visualize Architecture", command=self.trigger_arch, fg_color="#1F6AA5", hover_color="#144870")
        self.arch_btn.grid(row=8, column=0, padx=10, pady=10)
        
        self.history_btn = ctk.CTkButton(self.navigation_frame, text="Browse History", command=self.open_history_viewer, fg_color="#707070", hover_color="#505050")
        self.history_btn.grid(row=9, column=0, padx=10, pady=10)
        
        self.tree_btn = ctk.CTkButton(self.navigation_frame, text="View Code Tree", command=self.open_project_tree, fg_color="#1F6AA5", border_width=1)
        self.tree_btn.grid(row=10, column=0, padx=10, pady=10)
        
        self.stats_label = ctk.CTkLabel(self.navigation_frame, text="Project Stats", font=ctk.CTkFont(size=14, weight="bold"))
        self.stats_label.grid(row=11, column=0, pady=(20, 0))
        
        self.file_stat = ctk.CTkLabel(self.navigation_frame, text="Files: -")
        self.file_stat.grid(row=12, column=0)
        
        self.dir_stat = ctk.CTkLabel(self.navigation_frame, text="Dirs: -")
        self.dir_stat.grid(row=13, column=0)
        
        self.sloc_stat = ctk.CTkLabel(self.navigation_frame, text="Lines of Code: -", font=ctk.CTkFont(size=11, slant="italic"))
        self.sloc_stat.grid(row=14, column=0, pady=(10, 0))
        
        self.breakdown_label = ctk.CTkLabel(self.navigation_frame, text="Code Breakdown", font=ctk.CTkFont(size=12, weight="bold"))
        self.breakdown_label.grid(row=15, column=0, pady=(20, 5))
        
        self.breakdown_text = ctk.CTkLabel(self.navigation_frame, text="", font=ctk.CTkFont(size=10), justify="left")
        self.breakdown_text.grid(row=16, column=0, padx=10)

    def setup_main_area(self):
        self.main_frame = ctk.CTkFrame(self, corner_radius=10)
        self.main_frame.grid(row=0, column=1, sticky="nsew", padx=20, pady=20)
        
        self.status_label = ctk.CTkLabel(self.main_frame, text="AI Engine: AUTONOMOUS", font=ctk.CTkFont(size=24, weight="bold"), text_color="#00FFAA")
        self.status_label.pack(pady=20)
        
        # Resource Bars
        self.cpu_bar = self.create_resource_row("CPU Usage")
        self.ram_bar = self.create_resource_row("RAM Usage")
        self.disk_bar = self.create_resource_row("Disk Usage")
        
        # Network Display
        self.net_frame = ctk.CTkFrame(self.main_frame, fg_color="transparent")
        self.net_frame.pack(fill="x", padx=20, pady=5)
        self.up_label = ctk.CTkLabel(self.net_frame, text="Upload: 0 KB/s", text_color="#FFAA00")
        self.up_label.pack(side="left", padx=10)
        self.down_label = ctk.CTkLabel(self.net_frame, text="Download: 0 KB/s", text_color="#00AAFF")
        self.down_label.pack(side="left", padx=10)
        
        # Goals Area
        self.goals_frame = ctk.CTkFrame(self.main_frame, fg_color="#1A1A1A")
        self.goals_frame.pack(fill="x", padx=20, pady=10)
        self.goals_title = ctk.CTkLabel(self.goals_frame, text="EVOLUTION GOALS", font=ctk.CTkFont(size=12, weight="bold"))
        self.goals_title.pack(pady=5)
        self.goal_widgets = [] # List of (label, progress)
        
        # Health Indicator
        self.health_frame = ctk.CTkFrame(self.main_frame, fg_color="transparent")
        self.health_frame.pack(fill="x", padx=20)
        self.health_label = ctk.CTkLabel(self.health_frame, text="Code Health: EXCELLENT", font=ctk.CTkFont(size=12, weight="bold"), text_color="#00FFAA")
        self.health_label.pack(side="left")
        self.smells_label = ctk.CTkLabel(self.health_frame, text="", font=ctk.CTkFont(size=10, slant="italic"))
        self.smells_label.pack(side="left", padx=20)
        
        self.preview_btn = ctk.CTkButton(self.health_frame, text="Preview Fix", width=80, height=20, font=ctk.CTkFont(size=9), command=self.open_refactor_preview)
        self.preview_btn.pack(side="left", padx=5)
        
        self.test_health_label = ctk.CTkLabel(self.health_frame, text="Tests: N/A", font=ctk.CTkFont(size=10, weight="bold"), text_color="#AAAAAA")
        self.test_health_label.pack(side="right", padx=10)
        
        self.deps_frame = ctk.CTkFrame(self.main_frame, fg_color="transparent")
        self.deps_frame.pack(fill="x", padx=20)
        self.deps_label = ctk.CTkLabel(self.deps_frame, text="Package Health: CHECKING...", font=ctk.CTkFont(size=10))
        self.deps_label.pack(side="left")
        self.heal_btn = ctk.CTkButton(self.deps_frame, text="Heal Deps", width=80, height=20, font=ctk.CTkFont(size=9), fg_color="#FF3333", command=self.trigger_heal)
        self.heal_btn.pack(side="left", padx=10)
        self.heal_btn.pack_forget() # Hide by default
        
        # Timeline Area
        self.timeline_title = ctk.CTkLabel(self.main_frame, text="EVOLUTION TIMELINE", font=ctk.CTkFont(size=12, weight="bold"))
        self.timeline_title.pack(pady=(10,0))
        self.timeline_box = ctk.CTkTextbox(self.main_frame, height=100, font=ctk.CTkFont(size=11))
        self.timeline_box.pack(padx=20, pady=5, fill="x")
        
        # Log Box
        self.log_box.insert("0.0", self.engine.load_logs())
        
        self.analytics_btn = ctk.CTkButton(self.main_frame, text="View High-Res Analytics", command=self.open_analytics)
        self.analytics_btn.pack(pady=5)
        
        self.test_btn = ctk.CTkButton(self.main_frame, text="Run Self-Tests", command=self.trigger_tests, fg_color="#D1B000", hover_color="#B39700")
        self.test_btn.pack(pady=5)
        
        # History Canvas/Bar Frame
        self.history_frame = ctk.CTkFrame(self.main_frame, height=60, fg_color="transparent")
        self.history_frame.pack(fill="x", padx=20, pady=5)
        self.history_label = ctk.CTkLabel(self.history_frame, text="Trend (Last 15s):", font=ctk.CTkFont(size=12))
        self.history_label.pack(side="left")
        
        self.cpu_history_bars = []
        for _ in range(15):
            b = ctk.CTkProgressBar(self.history_frame, width=30, height=2, orientation="vertical")
            b.pack(side="left", padx=1)
            b.set(0)
            self.cpu_history_bars.append(b)

    def create_resource_row(self, label_text):
        frame = ctk.CTkFrame(self.main_frame, fg_color="transparent")
        frame.pack(fill="x", padx=20, pady=5)
        lbl = ctk.CTkLabel(frame, text=f"{label_text}: -", font=ctk.CTkFont(size=12))
        lbl.pack(side="left")
        bar = ctk.CTkProgressBar(frame)
        bar.pack(side="right", fill="x", expand=True, padx=(10, 0))
        bar.set(0)
        return (lbl, bar)

    def toggle_theme(self):
        new_mode = "light" if self.engine.config["appearance_mode"] == "dark" else "dark"
        self.engine.config["appearance_mode"] = new_mode
        ctk.set_appearance_mode(new_mode)
        self.engine.save_config(self.engine.config)
        self.add_log_to_ui(f"Theme toggled: {new_mode}")

    def change_personality(self, new_p):
        self.engine.config["personality"] = new_p
        self.engine.save_config(self.engine.config)
        self.engine.add_event("CONFIG", f"Strategy changed to {new_p}")
        self.add_log_to_ui(f"Evolution Strategy: {new_p}")
        self.update_personality_theme(new_p)

    def update_personality_theme(self, personality):
        themes = {
            "Default": {"color": "#00FFAA", "text": "Engine: AUTONOMOUS"},
            "Performance": {"color": "#00AAFF", "text": "Engine: HIGH PRIORITY"},
            "Safety": {"color": "#FFC107", "text": "Engine: DEEP SCANNING"},
            "Aesthetic": {"color": "#A371F7", "text": "Engine: DESIGN POLISH"}
        }
        theme = themes.get(personality, themes["Default"])
        self.status_label.configure(text=theme["text"], text_color=theme["color"])
        self.nav_label.configure(text_color=theme["color"])
        
    def add_log_to_ui(self, msg):
        log_line = self.engine.append_log(msg)
        self.log_box.insert("end", log_line)
        self.log_box.see("end")

    def trigger_backup(self):
        success, info = self.engine.perform_backup()
        if success:
            self.add_log_to_ui(f"Backup created: {info.split('/')[-1]}")
            self.engine.speak("Safety backup completed successfully.")
        else:
            self.add_log_to_ui(f"Backup failed: {info}")

    def trigger_cleanup(self):
        count = self.engine.cleanup_old_data(days=1)
        self.add_log_to_ui(f"Cleanup finished. Removed {count} old backups.")

    def trigger_report(self):
        report_file = self.engine.generate_evolution_report()
        self.add_log_to_ui(f"Report generated: {report_file}")
        self.engine.speak("Evolution report generated.")

    def trigger_docs(self):
        stats = self.engine.get_project_stats()
        sloc = self.engine.count_sloc()
        readme_content = f"""# Autonomous AI Evolution Environment
Enabled 24/7 autonomous project development.

## 📊 Live Metrics
- **Current SLOC:** {sloc}
- **File Count:** {stats['files']}
- **Last Sync:** {time.strftime('%Y-%m-%d %H:%M:%S')}

## 🛠️ Features
- Real-time Monitoring & Dashboard
- Autonomous Dependency Healing
- Self-Testing & Refactor Preview
- Historical Time-Machine
- Voice Notifications (TTS)

*Generated autonomously by the evolution engine.*
"""
        with open("README.md", "w", encoding="utf-8") as f:
            f.write(readme_content)
        self.add_log_to_ui("README.md synchronized with current state.")
        self.engine.speak("Documentation updated.")

    def trigger_arch(self):
        arch_file = self.engine.generate_dependency_graph()
        self.add_log_to_ui(f"Architecture mapped: {arch_file}")

    def trigger_tests(self):
        self.add_log_to_ui("Running autonomous test suite...")
        res = self.engine.run_self_tests()
        self.test_health_label.configure(text=f"Tests: {res['passed']}/{res['total']} PASSED", text_color="#00FFAA" if res['passed'] == res['total'] and res['total'] > 0 else "#FFAA00")
        self.add_log_to_ui(f"Test Results: {res['passed']}/{res['total']} successful.")

    def open_analytics(self):
        self.analytics_window = ctk.CTkToplevel(self)
        self.analytics_window.title("Evolution Performance Analytics")
        self.analytics_window.geometry("700x500")
        
        header = ctk.CTkLabel(self.analytics_window, text="High-Resolution Resource Trends", font=ctk.CTkFont(size=16, weight="bold"))
        header.pack(pady=10)
        
        self.analytics_canvas = ctk.CTkCanvas(self.analytics_window, height=350, bg="#1A1A1A", highlightthickness=0)
        self.analytics_canvas.pack(fill="both", expand=True, padx=20, pady=10)
        
        self.refresh_analytics_chart()

    def refresh_analytics_chart(self):
        if not hasattr(self, "analytics_canvas") or not self.analytics_window.winfo_exists():
            return
            
        self.analytics_canvas.delete("all")
        w = self.analytics_canvas.winfo_width()
        h = self.analytics_canvas.winfo_height()
        if w < 10: w = 660 # fallback
        if h < 10: h = 330
        
        # Grid lines
        for i in range(0, 101, 20):
            y = h - (i * h / 100)
            self.analytics_canvas.create_line(0, y, w, y, fill="#333333", dash=(4, 4))
            self.analytics_canvas.create_text(10, y-10, text=f"{i}%", fill="#666666", font=("Arial", 8))

        # CPU Chart
        self.draw_plot(self.analytics_canvas, self.engine.history["cpu"], "#00AAFF", w, h, "CPU")
        # RAM Chart
        self.draw_plot(self.analytics_canvas, self.engine.history["ram"], "#00FFAA", w, h, "RAM")
        # Health Chart (scaled for visibility)
        health_data = [min(100, x * 10) for x in self.engine.history["health"]]
        self.draw_plot(self.analytics_canvas, health_data, "#FFAA00", w, h, "HEALTH")

    def draw_plot(self, canvas, data, color, w, h, label):
        if not data: return
        points = []
        step = w / (len(data) - 1 if len(data) > 1 else 1)
        for i, val in enumerate(data):
            x = i * step
            y = h - (val * h / 100)
            points.append((x, y))
            
        if len(points) > 1:
            for i in range(len(points)-1):
                canvas.create_line(points[i][0], points[i][1], points[i+1][0], points[i+1][1], fill=color, width=2)
        
        # Legend
        offset = 20 if label == "CPU" else 60
        canvas.create_rectangle(w-80, offset, w-70, offset+10, fill=color)
        canvas.create_text(w-65, offset+5, text=label, fill="white", anchor="w", font=("Arial", 10))

    def open_refactor_preview(self):
        issues = self.engine.check_code_health()
        if not issues: return
        
        orig, suggested = self.engine.get_refactor_preview(issues[0])
        
        preview_win = ctk.CTkToplevel(self)
        preview_win.title("AI Refactor Preview")
        preview_win.geometry("800x500")
        
        f1 = ctk.CTkFrame(preview_win)
        f1.pack(side="left", fill="both", expand=True, padx=10, pady=10)
        ctk.CTkLabel(f1, text="Original Code").pack()
        t1 = ctk.CTkTextbox(f1, width=350)
        t1.pack(fill="both", expand=True)
        t1.insert("0.0", orig)
        
        f2 = ctk.CTkFrame(preview_win)
        f2.pack(side="left", fill="both", expand=True, padx=10, pady=10)
        ctk.CTkLabel(f2, text="Suggested Refactoring").pack()
        t2 = ctk.CTkTextbox(f2, width=350)
        t2.pack(fill="both", expand=True)
        t2.insert("0.0", suggested)
        
        def execute_refactor():
            success, msg = self.engine.apply_refactor(issues[0].split(":")[0].strip(), orig, suggested)
            if success:
                self.add_log_to_ui("Code successfully evolved.")
                self.engine.speak("Refactor applied. Evolution goal nearing.")
                preview_win.destroy()
            else:
                self.add_log_to_ui(f"Refactor failed: {msg}")
        
        btn = ctk.CTkButton(preview_win, text="APPLY REFACTOR", command=execute_refactor, fg_color="#00FFAA", text_color="#000000")
        btn.pack(pady=10)

    def open_insights(self):
        insights_win = ctk.CTkToplevel(self)
        insights_win.title("Project Insights & Heatmap")
        insights_win.geometry("600x500")
        
        ctk.CTkLabel(insights_win, text="Top Files by SLOC", font=ctk.CTkFont(size=14, weight="bold")).pack(pady=10)
        
        canvas = ctk.CTkCanvas(insights_win, height=350, bg="#1A1A1A", highlightthickness=0)
        canvas.pack(fill="both", expand=True, padx=20, pady=10)
        
        data = self.engine.get_heatmap_stats()
        if not data: return
        
        max_val = max(d[1] for d in data)
        w = 560
        h = 350
        bar_w = w / len(data) - 10
        
        for i, (name, val) in enumerate(data):
            bar_h = (val / max_val) * (h - 50)
            x0 = 20 + i * (bar_w + 10)
            y0 = h - bar_h - 20
            x1 = x0 + bar_w
            y1 = h - 20
            
            canvas.create_rectangle(x0, y0, x1, y1, fill="#AA66FF", outline="#FFFFFF")
            canvas.create_text(x0 + bar_w/2, y1 + 10, text=name[:6], fill="white", font=("Arial", 8))
            canvas.create_text(x0 + bar_w/2, y0 - 10, text=str(val), fill="#AA66FF", font=("Arial", 8))

    def open_history_viewer(self):
        backups = self.engine.get_backup_list()
        if not backups:
            self.add_log_to_ui("No backups found to browse.")
            return
            
        history_win = ctk.CTkToplevel(self)
        history_win.title("Historical Snapshot Viewer")
        history_win.geometry("900x600")
        
        top_bar = ctk.CTkFrame(history_win)
        top_bar.pack(fill="x", padx=10, pady=10)
        
        ctk.CTkLabel(top_bar, text="Select Snapshot:").pack(side="left", padx=5)
        snap_menu = ctk.CTkOptionMenu(top_bar, values=backups)
        snap_menu.pack(side="left", padx=5)
        
        ctk.CTkLabel(top_bar, text="File:").pack(side="left", padx=5)
        file_entry = ctk.CTkEntry(top_bar, width=200)
        file_entry.insert(0, "system_engine.py")
        file_entry.pack(side="left", padx=5)
        
        def load_comparison():
            zip_file = snap_menu.get()
            target_file = file_entry.get()
            old_content = self.engine.get_file_from_backup(zip_file, target_file)
            new_content = ""
            if os.path.exists(target_file):
                with open(target_file, "r", encoding="utf-8", errors='replace') as f:
                    new_content = f.read()
            
            t_old.delete("0.0", "end")
            t_old.insert("0.0", old_content)
            t_new.delete("0.0", "end")
            t_new.insert("0.0", new_content)
        
        ctk.CTkButton(top_bar, text="Compare", command=load_comparison).pack(side="left", padx=10)
        
        diff_frame = ctk.CTkFrame(history_win)
        diff_frame.pack(fill="both", expand=True, padx=10, pady=5)
        
        f_old = ctk.CTkFrame(diff_frame)
        f_old.pack(side="left", fill="both", expand=True, padx=5)
        ctk.CTkLabel(f_old, text="PAST").pack()
        t_old = ctk.CTkTextbox(f_old)
        t_old.pack(fill="both", expand=True)
        
        f_new = ctk.CTkFrame(diff_frame)
        f_new.pack(side="left", fill="both", expand=True, padx=5)
        ctk.CTkLabel(f_new, text="PRESENT").pack()
        t_new = ctk.CTkTextbox(f_new)
        t_new.pack(fill="both", expand=True)

    def open_project_tree(self):
        tree_win = ctk.CTkToplevel(self)
        tree_win.title("Visual Codebase Explorer")
        tree_win.geometry("500x600")
        
        header = ctk.CTkLabel(tree_win, text="Project Structure", font=ctk.CTkFont(size=14, weight="bold"))
        header.pack(pady=10)
        
        tree_box = ctk.CTkTextbox(tree_win, font=("Consolas", 10))
        tree_box.pack(fill="both", expand=True, padx=20, pady=20)
        
        tree_data = self.engine.get_project_tree()
        tree_box.insert("0.0", tree_data)
        tree_box.configure(state="disabled")

    def trigger_heal(self):
        missing = self.engine.check_dependencies()
        if not missing: return
        self.add_log_to_ui(f"Healing {len(missing)} dependencies: {missing}")
        for pkg in missing:
            success, msg = self.engine.install_dependency(pkg)
            if success:
                self.add_log_to_ui(f"Healed: {pkg}")
                self.engine.speak(f"Successfully installed package {pkg}")
            else:
                self.add_log_to_ui(f"Heal failed for {pkg}: {msg}")
        self.update_dependency_status()

    def update_dependency_status(self):
        missing = self.engine.check_dependencies()
        if missing:
            self.deps_label.configure(text=f"Package Health: {len(missing)} MISSING ({', '.join(missing)})", text_color="#FF3333")
            self.heal_btn.pack(side="left", padx=10)
        else:
            self.deps_label.configure(text="Package Health: PERFECT", text_color="#00FFAA")
            self.heal_btn.pack_forget()

    def update_loop(self):
        stats = self.engine.get_system_stats()
        
        # Health Update
        issues = self.engine.check_code_health()
        stats["smells"] = len(issues)
        
        self.cpu_bar[0].configure(text=f"CPU: {stats['cpu']}%")
        self.cpu_bar[1].set(stats['cpu']/100)
        
        self.ram_bar[0].configure(text=f"RAM: {stats['ram_percent']}% ({stats['ram_used_mb']}MB)")
        self.ram_bar[1].set(stats['ram_percent']/100)
        
        self.disk_bar[0].configure(text=f"Disk: {stats['disk_percent']}% ({stats['disk_free_gb']}GB Free)")
        self.disk_bar[1].set(stats['disk_percent']/100)
        
        self.up_label.configure(text=f"Upload: {stats['net_up_kb']:.1f} KB/s")
        self.down_label.configure(text=f"Download: {stats['net_down_kb']:.1f} KB/s")
        
        # Project stats (every 5s roughly via modulo or separate counter, here just simplified)
        p_stats = self.engine.get_project_stats()
        sloc = self.engine.count_sloc()
        self.file_stat.configure(text=f"Files: {p_stats['files']}")
        self.dir_stat.configure(text=f"Dirs: {p_stats['dirs']}")
        self.sloc_stat.configure(text=f"Lines of Code: {sloc}")
        
        # Breakdown update
        bd = self.engine.get_code_breakdown()
        bd_str = "\n".join([f"{k}: {v}" for k, v in bd.items() if v > 0])
        self.breakdown_text.configure(text=bd_str)
        
        # Evolution Goals update
        goal_status = self.engine.get_goal_status()
        if not self.goal_widgets:
            for g in goal_status:
                g_lbl = ctk.CTkLabel(self.goals_frame, text=f"{g['name']}: {g['current']}/{g['target']}", font=ctk.CTkFont(size=10))
                g_lbl.pack()
                g_bar = ctk.CTkProgressBar(self.goals_frame, height=8)
                g_bar.pack(fill="x", padx=20, pady=(0, 10))
                self.goal_widgets.append((g_lbl, g_bar))
        
        for i, g in enumerate(goal_status):
            self.goal_widgets[i][0].configure(text=f"{g['name']}: {g['current']}/{g['target']}")
            self.goal_widgets[i][1].set(g['percent'])
            if g['percent'] >= 1.0: self.goal_widgets[i][1].configure(progress_color="#00FF00")

        # Health Update
        issues = self.engine.check_code_health()
        if not issues:
            self.health_label.configure(text="Code Health: EXCELLENT", text_color="#00FFAA")
            self.smells_label.configure(text="")
        else:
            self.health_label.configure(text=f"Code Health: {len(issues)} SMELLS", text_color="#FFAA00")
            advice = self.engine.get_refactor_advice(issues)
            self.smells_label.configure(text=" | ".join(advice))
            
        # Timeline Update
        current_timeline = "\n".join([f"[{e['time']}] {e['type']}: {e['msg']}" for e in self.engine.event_history])
        self.timeline_box.configure(state="normal")
        self.timeline_box.delete("0.0", "end")
        self.timeline_box.insert("0.0", current_timeline)
        self.timeline_box.configure(state="disabled")

        
        # Update History & Visualization
        self.engine.update_history(stats)
        
        # Periodic Personality Quote (1% chance / sec)
        if random.random() < 0.01:
            quote = self.engine.get_personality_quote()
            self.add_log_to_ui(f"AI: {quote}")
            self.engine.speak(quote)
            
        for i, val in enumerate(self.engine.history["cpu"]):
            if i < len(self.cpu_history_bars):
                self.cpu_history_bars[i].set(val/100)
        
        # Automated Backup Check (every hour = 3600s)
        if time.time() - self.engine.last_auto_backup > 3600:
            self.engine.last_auto_backup = time.time()
            self.trigger_backup()
            self.add_log_to_ui("🕒 Automated hourly backup triggered.")
        
        # CSV Performance Logging (every 60s)
        if stats["cpu"] > 90 or stats["ram_percent"] > 90:
            self.anomaly_count += 1
            if self.anomaly_count == 3:
                self.engine.speak("Warning: High resource anomaly detected.")
                self.add_log_to_ui("CRITICAL: Resource usage exceeded 90% for 3 cycles.")
        else:
            self.anomaly_count = 0

        if time.time() - self.last_csv_log > 60:
            self.last_csv_log = time.time()
            self.engine.log_performance_csv(stats)
            
        if time.time() - self.last_dep_check > 30:
            self.last_dep_check = time.time()
            self.update_dependency_status()
            self.refresh_analytics_chart()
        
        self.after(1000, self.update_loop)
