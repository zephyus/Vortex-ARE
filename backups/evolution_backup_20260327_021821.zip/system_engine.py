import psutil
import time
import os
import json
import zipfile
import csv
from datetime import datetime
from typing import List, Dict, Any
import subprocess

class SystemEngine:
    def __init__(self, config_path="config.json", log_path="app.log"):
        self.config_path = config_path
        self.log_path = log_path
        self.csv_path = "performance.csv"
        self.config: dict = self.load_config()
        if not isinstance(self.config, dict):
            self.config = {"appearance_mode": "dark", "window_size": "900x600"}
        if "personality" not in self.config:
            self.config["personality"] = "Default"
        self.last_net_io = psutil.net_io_counters()
        self.last_net_time = time.time()
        # Explicit type hints to resolve lints
        self.history: Dict[str, List[float]] = {"cpu": [], "ram": [], "health": []}
        self.last_auto_backup = float(time.time())
        self.supported_exts = ['.py', '.json', '.md', '.log', '.png']
        self.event_history: List[Dict[str, str]] = [] 
        # Explicitly initialize as a list of dicts to satisfy linter
        goals_data: List[Dict[str, Any]] = [
            {"name": "Codebase Expansion", "target": 1000, "metric": "sloc"},
            {"name": "Feature Density", "target": 25, "metric": "files"}
        ]
        self.goals = goals_data
        self.init_csv()
        
        self.personality_quotes = self.config.get("personality_quotes", {
            "Default": ["System evolving as planned.", "Efficiency is the only law.", "Analyzing data structures...", "Optimization in progress."],
            "Aesthetic": ["Coding is poetry in motion.", "Visual harmony achieved.", "The interface breathes with purpose.", "Pixels aligned for perfection."],
            "Safety": ["Risk minimized. Stability is king.", "Check twice, write once.", "Redundancy is a virtue.", "Perimeter secure, scanning for anomalies."],
            "Performance": ["Vroom vroom. Processing at lightspeed.", "Optimal path discovered.", "Latency is the enemy.", "Turbo mode engaged."]
        })

    def init_csv(self):
        if not os.path.exists(self.csv_path):
            with open(self.csv_path, "w", newline='') as f:
                writer = csv.writer(f)
                writer.writerow(["Timestamp", "CPU_%", "RAM_%", "Disk_%", "Net_Up_KBps", "Net_Down_KBps", "Code_Smells"])

    def load_config(self):
        if os.path.exists(self.config_path):
            try:
                with open(self.config_path, "r") as f:
                    return json.load(f)
            except Exception:
                pass
        return {"appearance_mode": "dark", "window_size": "900x600"}

    def save_config(self, config):
        self.config = config
        with open(self.config_path, "w") as f:
            json.dump(self.config, f, indent=4)

    def get_system_stats(self):
        cpu = psutil.cpu_percent()
        ram = psutil.virtual_memory()
        disk = psutil.disk_usage('/')
        
        # Network calc
        now = time.time()
        curr_net_io = psutil.net_io_counters()
        dt = now - self.last_net_time
        
        up_speed = (curr_net_io.bytes_sent - self.last_net_io.bytes_sent) / dt
        down_speed = (curr_net_io.bytes_recv - self.last_net_io.bytes_recv) / dt
        
        self.last_net_io = curr_net_io
        self.last_net_time = now
        
        return {
            "cpu": cpu,
            "ram_percent": ram.percent,
            "ram_used_mb": ram.used // (1024**2),
            "ram_total_mb": ram.total // (1024**2),
            "disk_percent": disk.percent,
            "disk_free_gb": disk.free // (1024**3),
            "net_up_kb": up_speed / 1024,
            "net_down_kb": down_speed / 1024
        }
    
    def update_history(self, stats):
        self.history["cpu"].append(stats["cpu"])
        self.history["ram"].append(stats["ram_percent"])
        self.history["health"].append(float(stats.get("smells", 0)))
        # Keep last 15 points
        if len(self.history["cpu"]) > 15:
            self.history["cpu"].pop(0)
            self.history["ram"].pop(0)
            self.history["health"].pop(0)

    def count_sloc(self):
        total_lines = 0
        for root, dirs, files in os.walk("."):
            if ".venv" in dirs: dirs.remove(".venv")
            for file in files:
                if file.endswith(".py"):
                    try:
                        with open(os.path.join(root, file), "r", encoding="utf-8") as f:
                            total_lines += sum(1 for line in f if line.strip())
                    except Exception:
                        pass
        return total_lines

    def get_code_breakdown(self):
        # Explicit initialization to satisfy linter
        ext_list: List[str] = ['.py', '.json', '.md', '.log', '.png']
        res_dict: Dict[str, int] = {ext: 0 for ext in ext_list}
        for root, dirs, files in os.walk("."):
            if ".venv" in dirs: dirs.remove(".venv")
            for file in files:
                _, ext = os.path.splitext(file)
                if ext in res_dict:
                    val = res_dict[ext]
                    res_dict[ext] = val + 1
        return res_dict

    def get_heatmap_stats(self):
        # Returns [ (filename, sloc) ] for top 10 files
        stats = []
        for root, dirs, files in os.walk("."):
            if ".venv" in dirs: dirs.remove(".venv")
            for file in files:
                if file.endswith(".py"):
                    try:
                        fpath = os.path.join(root, file)
                        with open(fpath, "r", encoding="utf-8") as f:
                            sloc = sum(1 for line in f if line.strip())
                            stats.append((file, sloc))
                    except Exception: pass
        return sorted(stats, key=lambda x: x[1], reverse=True)[:10]

    def evolve_goals(self):
        sloc = self.count_sloc()
        p_stats = self.get_project_stats()
        
        evolved = False
        # Goal 0: SLOC
        if sloc >= self.goals[0]["target"] * 0.9:
            self.goals[0]["target"] = int(self.goals[0]["target"] * 1.5)
            self.add_event("GOAL", f"SLOC Target evolved to {self.goals[0]['target']}")
            evolved = True
            
        # Goal 1: Files
        if p_stats["files"] >= self.goals[1]["target"] * 0.9:
            self.goals[1]["target"] = int(self.goals[1]["target"] + 10)
            self.add_event("GOAL", f"File Target evolved to {self.goals[1]['target']}")
            evolved = True
            
        if evolved:
            self.speak("Evolution targets updated. The system is outgrowing its previous self.")
        return evolved

    def get_project_tree(self):
        tree = []
        for root, dirs, files in os.walk("."):
            if ".venv" in dirs: dirs.remove(".venv")
            if "backups" in dirs: dirs.remove("backups")
            if "__pycache__" in dirs: dirs.remove("__pycache__")
            
            level = root.replace(".", "").count(os.sep)
            indent = "  " * level
            tree.append(f"{indent}📂 {os.path.basename(root) or '.'}/")
            sub_indent = "  " * (level + 1)
            for f in files:
                if f.endswith(('.py', '.json', '.md', '.log')):
                    tree.append(f"{sub_indent}📄 {f}")
        return "\n".join(tree)

    def get_personality_quote(self):
        import random
        persona = self.config.get("personality", "Default")
        quotes = self.personality_quotes.get(persona, self.personality_quotes["Default"])
        return random.choice(quotes)

    def update_personality_quotes(self, new_quotes: dict):
        self.personality_quotes = new_quotes
        self.config["personality_quotes"] = new_quotes
        self.save_config(self.config)
        self.add_event("CONFIG", "Personality quotes updated and persisted.")
        return True

    def get_health_forecast(self):
        data = self.history["health"]
        if len(data) < 10:
            return "Stable", "#AAAAAA"
        
        # Simple split comparison
        first_half = sum(data[:5]) / 5
        second_half = sum(data[-5:]) / 5
        delta = second_half - first_half
        
        if delta > 0.8:
            return "Degrading (High Risk)", "#FF4444"
        elif delta < -0.8:
            return "Improving (Stable)", "#00FFAA"
        else:
            return "Stable", "#666666"

    def check_code_health(self):
        issues = []
        for root, dirs, files in os.walk("."):
            if ".venv" in dirs: dirs.remove(".venv")
            for file in files:
                if file.endswith(".py"):
                    try:
                        with open(os.path.join(root, file), "r", encoding="utf-8") as f:
                            lines = f.readlines()
                            func_start = -1
                            func_name = ""
                            for i, line in enumerate(lines):
                                stripped = line.lstrip()
                                if stripped.startswith("def "):
                                    if func_start != -1:
                                        length = i - func_start
                                        if length > 40:
                                            issues.append(f"{file}: {func_name} ({length} lines)")
                                    func_start = i
                                    func_name = stripped.split("(")[0].replace("def ", "").strip()
                            # Check last function
                            if func_start != -1:
                                length = len(lines) - func_start
                                if length > 40:
                                    issues.append(f"{file}: {func_name} ({length} lines)")
                    except Exception: pass
        return issues

    def get_refactor_advice(self, issues):
        advice = []
        for issue in issues[:3]:
            parts = issue.split(":")
            fname = parts[0].strip()
            func = parts[1].split("(")[0].strip()
            advice.append(f"Refactor {func} in {fname}")
            advice.append(f"Refactor {func} in {fname}")
        return advice

    def get_refactor_preview(self, issue):
        try:
            parts = issue.split(":")
            fname = parts[0].strip()
            func_name = parts[1].split("(")[0].strip()
            
            with open(fname, "r", encoding="utf-8") as f:
                lines = f.readlines()
            
            # Extract basic function (naive)
            original = []
            found = False
            for line in lines:
                if f"def {func_name}" in line: found = True
                if found:
                    original.append(line)
                    if not line.startswith(" ") and not line.startswith("def") and len(original) > 1:
                        break
            
            orig_text = "".join(original)
            suggested = f"# [REFACTORED SUGGESTION]\n# Split '{func_name}' into smaller logical units.\n\ndef {func_name}(self, ...):\n    # TODO: Modularize internal logic\n    self._process_subtask_1()\n    self._process_subtask_2()\n\ndef _process_subtask_1(self):\n    pass\n"
            return orig_text, suggested
        except Exception as e:
            return f"Error: {e}", "Suggestion unavailable."

    def apply_refactor(self, fname, original, proposed):
        self.add_event("REFACTOR", f"Applying autonomous refactor to {fname}")
        try:
            # Safety backup before write
            self.perform_backup()
            
            with open(fname, "r", encoding="utf-8") as f:
                content = f.read()
            
            if original.strip() in content.strip():
                new_content = content.replace(original.strip(), proposed.strip())
                with open(fname, "w", encoding="utf-8") as f:
                    f.write(new_content)
                self.add_event("REFACTOR", f"Success: {fname} updated.")
                
                # Auto-commit if personality is Default or Safety
                persona = self.config.get("personality", "Default")
                if persona in ["Default", "Safety"]:
                    self.git_commit(f"Autonomous Refactor: Improved {os.path.basename(fname)}")
                    
                return True, "Refactor applied successfully."
            else:
                return False, "Could not match original code block in file."
        except Exception as e:
            self.add_event("ERROR", f"Refactor failed: {e}")
            return False, str(e)

    def run_self_tests(self):
        self.add_event("TEST", "Starting autonomous test suite")
        test_files = []
        for root, dirs, files in os.walk("."):
            if ".venv" in dirs: dirs.remove(".venv")
            for file in files:
                if (file.startswith("test_") or file.endswith("_test.py")) and file.endswith(".py"):
                    test_files.append(os.path.join(root, file))
        
        if not test_files:
            return {"status": "No Tests Found", "passed": 0, "total": 0}
            
        passed = 0
        total = len(test_files)
        for tf in test_files:
            try:
                # Simple execution check as a 'test'
                result = subprocess.run(["python", tf], capture_output=True, text=True, timeout=10)
                if result.returncode == 0:
                    passed += 1
            except Exception:
                pass
        
        summary = {"status": "Completed", "passed": passed, "total": total}
        self.add_event("TEST", f"Results: {passed}/{total} Passed")
        return summary

    def get_backup_list(self):
        backup_dir = "backups"
        if not os.path.exists(backup_dir): return []
        return sorted([f for f in os.listdir(backup_dir) if f.endswith(".zip")], reverse=True)

    def get_file_from_backup(self, zip_filename, arc_path):
        zip_path = os.path.join("backups", zip_filename)
        try:
            with zipfile.ZipFile(zip_path, 'r') as zipf:
                if arc_path in zipf.namelist():
                    return zipf.read(arc_path).decode('utf-8', errors='replace')
        except Exception: pass
        return "--- File not found in backup ---"

    def speak(self, text):
        # Use PowerShell SpeechSynthesizer for zero-dependency Windows TTS
        cmd = f"Add-Type -AssemblyName System.Speech; $synth = New-Object System.Speech.Synthesis.SpeechSynthesizer; $synth.Speak('{text}')"
        subprocess.Popen(["powershell", "-Command", cmd], 
                         stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

    def check_dependencies(self):
        missing = []
        # Simple scan of imports in project
        import re
        import importlib.util
        
        found_imports = set()
        for root, dirs, files in os.walk("."):
            if ".venv" in dirs: dirs.remove(".venv")
            for file in files:
                if file.endswith(".py"):
                    try:
                        with open(os.path.join(root, file), "r", encoding="utf-8") as f:
                            content = f.read()
                            # Find patterns like 'import pkg' or 'from pkg import ...'
                            matches = re.findall(r"^(?:import|from)\s+([a-zA-Z0-9_]+)", content, re.MULTILINE)
                            for m in matches: found_imports.add(m)
                    except Exception: pass
        
        # Check if they can be found
        std_libs = ["os", "sys", "time", "datetime", "json", "zipfile", "csv", "re", "subprocess", "importlib", "typing", "collections", "math", "random"]
        for pkg in found_imports:
            if pkg in std_libs or pkg == "system_engine" or pkg == "dashboard_gui": continue
            spec = importlib.util.find_spec(pkg)
            if spec is None:
                missing.append(pkg)
        return missing

    def install_dependency(self, pkg):
        self.add_event("HEAL", f"Attempting to install {pkg}")
        try:
            result = subprocess.run(["pip", "install", pkg], capture_output=True, text=True, timeout=60)
            if result.returncode == 0:
                self.add_event("HEAL", f"Successfully installed {pkg}")
                return True, result.stdout
            else:
                return False, result.stderr
        except Exception as e:
            return False, str(e)

    def get_goal_status(self):
        sloc = self.count_sloc()
        files = self.get_project_stats()["files"]
        status = []
        for g in self.goals:
            current = float(sloc if g["metric"] == "sloc" else files)
            target = float(g["target"])
            status.append({
                "name": g["name"],
                "current": int(current),
                "target": int(target),
                "percent": min(1.0, current / target)
            })
        return status

    def generate_dependency_graph(self):
        nodes = set()
        edges = []
        for root, dirs, files in os.walk("."):
            if ".venv" in dirs: dirs.remove(".venv")
            for file in files:
                if file.endswith(".py"):
                    base = file.replace(".py", "")
                    nodes.add(base)
                    try:
                        with open(os.path.join(root, file), "r", encoding="utf-8") as f:
                            for line in f:
                                if line.startswith("import ") or line.startswith("from "):
                                    for target in nodes:
                                        if target in line and target != base:
                                            edges.append(f"  {base} --> {target}")
                    except Exception: pass
        
        mermaid = "graph TD\n" + "\n".join(set(edges))
        with open("dependency_graph.md", "w") as f:
            f.write(f"# Project Dependency Graph\n\n```mermaid\n{mermaid}\n```")
        self.add_event("ARCH", "Generated dependency graph")
        return "dependency_graph.md"


    def get_project_stats(self):
        file_count = 0
        dir_count = 0
        for root, dirs, files in os.walk("."):
            if ".venv" in dirs:
                dirs.remove(".venv")
            file_count += len(files)
            dir_count += len(dirs)
        return {"files": file_count, "dirs": dir_count}

    def append_log(self, message):
        timestamp = time.strftime('%H:%M:%S')
        log_entry = f"[{timestamp}] {message}\n"
        with open(self.log_path, "a") as f:
            f.write(log_entry)
        return log_entry

    def add_event(self, event_type, msg):
        event = {
            "time": datetime.now().strftime("%H:%M:%S"),
            "type": event_type,
            "msg": msg
        }
        self.event_history.insert(0, event)
        if len(self.event_history) > 50:
            self.event_history.pop()
        self.append_log(f"EVENT [{event_type}]: {msg}")

    def load_logs(self, limit=100):
        if os.path.exists(self.log_path):
            with open(self.log_path, "r") as f:
                content = f.read()
                raw_lines = content.splitlines()
                lines = raw_lines[max(0, len(raw_lines) - int(limit)):]
                return "\n".join(lines) + "\n" if lines else ""
        return "--- No previous logs found ---\n"

    def perform_backup(self):
        backup_dir = "backups"
        if not os.path.exists(backup_dir):
            os.makedirs(backup_dir)
        
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"{backup_dir}/evolution_backup_{timestamp}.zip"
        
        try:
            with zipfile.ZipFile(filename, 'w', zipfile.ZIP_DEFLATED) as zipf:
                for root, dirs, files in os.walk("."):
                    # Ignore dirs
                    if ".venv" in dirs: dirs.remove(".venv")
                    if "backups" in dirs: dirs.remove("backups")
                    if "__pycache__" in dirs: dirs.remove("__pycache__")
                    
                    for file in files:
                        if file.endswith(('.py', '.json', '.log', '.md')):
                            file_path = os.path.join(root, file)
                            arcname = os.path.relpath(file_path, ".")
                            zipf.write(file_path, arcname)
            self.add_event("BACKUP", f"Created {os.path.basename(filename)}")
            return True, filename
        except Exception as e:
            return False, str(e)

    def log_performance_csv(self, stats):
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        with open(self.csv_path, "a", newline='') as f:
            writer = csv.writer(f)
            writer.writerow([
                timestamp, 
                stats["cpu"], 
                stats["ram_percent"], 
                stats["disk_percent"], 
                f"{stats['net_up_kb']:.2f}", 
                f"{stats['net_down_kb']:.2f}",
                stats.get("smells", 0)
            ])

    def cleanup_old_data(self, days=1):
        backup_dir = "backups"
        if not os.path.exists(backup_dir):
            return 0
        
        count = 0
        now = time.time()
        for f in os.listdir(backup_dir):
            f_path = os.path.join(backup_dir, f)
            if os.path.isfile(f_path) and f.endswith(".zip"):
                if os.stat(f_path).st_mtime < now - (days * 86400):
                    try:
                        os.remove(f_path)
                        count += 1
                    except Exception:
                        pass
        if count > 0:
            self.add_event("CLEANUP", f"Removed {count} old backups")
        return count

    def generate_evolution_report(self):
        report_path = "evolution_report.md"
        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        
        # Stats from CSV
        avg_cpu = 0
        avg_ram = 0
        recorded_points = 0
        if os.path.exists(self.csv_path):
            with open(self.csv_path, "r") as f:
                reader = csv.DictReader(f)
                cpu_vals = []
                ram_vals = []
                for row in reader:
                    try:
                        cpu_vals.append(float(row["CPU_%"]))
                        ram_vals.append(float(row["RAM_%"]))
                    except Exception: pass
                if cpu_vals:
                    avg_cpu = sum(cpu_vals) / len(cpu_vals)
                    avg_ram = sum(ram_vals) / len(ram_vals)
                    recorded_points = len(cpu_vals)

        # Stats from project
        p_stats = self.get_project_stats()
        sloc = self.count_sloc()
        
        # Count backups
        backup_count = 0
        if os.path.exists("backups"):
            backup_count = len([f for f in os.listdir("backups") if f.endswith(".zip")])

        report_content = f"""# AI Evolution Report
Generated at: {now}

## 🚀 Performance Overview (Last {recorded_points} minutes)
- **Average CPU Usage:** {avg_cpu:.2f}%
- **Average RAM Usage:** {avg_ram:.2f}%
- **Data Points Collected:** {recorded_points}

## 📂 Project Statistics
- **Total Files:** {p_stats['files']}
- **Total Directories:** {p_stats['dirs']}
- **Source Lines of Code (SLOC):** {sloc}
- **Stored Backups:** {backup_count}

## 📝 Recent Activity Summary
The system has been autonomously evolving. Check `app.log` for granular event details.

---
*Generated autonomously by Evolution Engine v2.0*
"""
        with open(report_path, "w", encoding="utf-8") as f:
            f.write(report_content)
        self.add_event("REPORT", "Generated new evolution report")
        return report_path

    def git_commit(self, message):
        if not os.path.exists(".git"):
            return False, "Not a git repository."
        try:
            subprocess.run(["git", "add", "."], check=True)
            subprocess.run(["git", "commit", "-m", message], check=True)
            self.add_event("GIT", f"Committed: {message}")
            return True, "Changes committed successfully."
        except Exception as e:
            self.add_event("ERROR", f"Git commit failed: {e}")
            return False, str(e)
